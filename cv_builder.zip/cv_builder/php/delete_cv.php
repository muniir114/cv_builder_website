<?php
// Include your database connection file
include('db.php');

// Start session
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // The ID of the logged-in user

// Check if CV ID is provided
if (isset($_GET['cv_id']) && is_numeric($_GET['cv_id'])) {
    $cv_id = $_GET['cv_id'];

    // Start transaction
    $conn->begin_transaction();
    try {
        // Delete related records from education, experience, tasks, etc.
        $stmt = $conn->prepare("DELETE FROM education WHERE cv_id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM experience WHERE cv_id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM task WHERE cv_id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM skills WHERE cv_id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM languages WHERE cv_id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        $stmt = $conn->prepare("DELETE FROM hobbies WHERE cv_id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        // Finally, delete the CV
        $stmt = $conn->prepare("DELETE FROM cvs WHERE id = ?");
        $stmt->bind_param("i", $cv_id);
        $stmt->execute();

        // Commit transaction
        $conn->commit();

        // Redirect or show success message
        header("Location: create_cv.php");
        exit();

    } catch (Exception $e) {
        // Rollback transaction if something goes wrong
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "Invalid CV ID.";
}
?>
