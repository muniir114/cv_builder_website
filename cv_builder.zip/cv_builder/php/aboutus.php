
<?php
session_start();  // Start the session to check login status
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="../css/general.css">
</head>
<body>
<div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Navigation</h3>
            <a href="../index.php">Home</a>
            <a href="create_cv.php">Create CV</a>
            <a href="contact.php">Contact</a>
            <a href="skills_progression.php">Skills Progression</a>
            <a href="#">About Us</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- Show Logout link if the user is logged in -->
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <!-- Show Login link if the user is NOT logged in -->
                <a href="login.php">Login</a>
            <?php endif; ?>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <h2 class="text-center text-primary mb-4">About Us</h2>
            <div class="about-us">
                <h4>Our Story</h4>
                <p>We are a team of passionate students with a couple of years of experience, who are dedicated to helping people with a simple CV website.</p>
                <p>Our CV website is for students & people who are in need of a simple CV that gives a positive message to their future employers.</p>
                <p>This page has everything you need, including skill progression.</p>

                <h4>Our Team</h4>

                <div class="row team-member">
                    <!-- Team Member 1 -->
                    <div class="col-md-3 text-center">
                        <img src="img_12.jpeg" alt="Team Member" class="img-fluid rounded-circle mb-2">
                        <h5>Mohamed Osman Abdi</h5>
                        <p>Full-Stack Developer</p>
                        <p>Phone Number - +3580000000</p>
                    </div>

                    <!-- Team Member 2 -->
                    <div class="col-md-3 text-center">
                        <img src="https://via.placeholder.com/150" alt="Team Member" class="img-fluid rounded-circle mb-2">
                        <h5>Mohammed Alyasin</h5>
                        <p>Front-End Web Developer</p>
                        <p>Phone Number - +3580000000</p>
                    </div>

                    <!-- Team Member 3 -->
                    <div class="col-md-3 text-center">
                        <img src="https://via.placeholder.com/150" alt="Team Member" class="img-fluid rounded-circle mb-2">
                        <h5>Artturi Nurmi</h5>
                        <p>Front-End Web Developer</p>
                        <p>Phone Number - +3580000000</p>
                    </div>

                    <!-- Team Member 4 -->
                    <div class="col-md-3 text-center">
                        <img src="https://via.placeholder.com/150" alt="Team Member" class="img-fluid rounded-circle mb-2">
                        <h5>Luukas Laurila</h5>
                        <p>Front-End Web Developer</p>
                        <p>Phone Number - +3580000000</p>
                    </div>
                </div>
            </div>
        </div>    
</div>

<footer class="footer">
    <p>&copy; 2024 CV Builder. All rights reserved. Mohamed Osman Abdi</p>
    <div class="footer-icons">
        <a href="https://github.com/turkuai/web-cv-team-4">Github</a>
        <a href="#">Twitter</a>
        <a href="#">Link</a>
        <a href="#">Discord</a>
    </div>
</footer>

<!-- Bootstrap JS (Popper.js and Bootstrap JS) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>

</body>
</html>