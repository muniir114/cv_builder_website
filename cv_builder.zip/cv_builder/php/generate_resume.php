<?php
ob_start();  // Start output buffering

include('db.php');
require_once('tcpdf/tcpdf.php');  // Include TCPDF library

// Ensure the cv_id is provided
if (!isset($_GET['cv_id'])) {
    echo "CV ID not provided in the URL.";
    exit();
}

$cv_id = $_GET['cv_id'];  // Get the cv_id from the URL

// Fetch the CV data from the database, ensuring that the CV is not marked as deleted
$stmt = $conn->prepare("SELECT * FROM cvs WHERE id = ? AND deleted = 0");
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$cv_result = $stmt->get_result();

if ($cv_result->num_rows == 0) {
    echo "CV not found or it has been deleted.";
    exit();
}

$cv = $cv_result->fetch_assoc();

// Fetch user information using user_id from cvs table
$user_stmt = $conn->prepare("SELECT name, email, phone_number, address FROM users WHERE id = ?");
$user_stmt->bind_param("i", $cv['user_id']);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

function generate_pdf($cv, $user, $conn) {
    // Create the PDF
    $pdf = new TCPDF();
    $pdf->SetAutoPageBreak(TRUE, 15);
    $pdf->AddPage();

    // Add header
    $pdf->SetFont('Helvetica', 'B', 17);
    $pdf->Cell(0, 10, 'Curriculum Vitae', 0, 1, 'C');
    $pdf->Ln(10);  // Add line break

    // User Information Section
    $pdf->SetFont('Helvetica', '', 12);
    $pdf->Cell(0, 10, 'Name: ' . $user['name'], 0, 1);
    $pdf->Cell(0, 10, 'Email: ' . $user['email'], 0, 1);
    $pdf->Cell(0, 10, 'Phone: ' . $user['phone_number'], 0, 1);
    $pdf->Cell(0, 10, 'Address: ' . $user['address'], 0, 1);
    $pdf->Ln(10);

    // CV Description
    $pdf->Cell(0, 10, 'Description: ' . $cv['description'], 0, 1);
    $pdf->Ln(10);

    // --- Education Section ---
    $pdf->SetFont('Helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Education', 0, 1);
    $pdf->SetFont('Helvetica', '', 12);
    
    $edu_stmt = $conn->prepare("SELECT * FROM education WHERE cv_id = ? AND deleted = 0");
    $edu_stmt->bind_param("i", $cv['id']);
    $edu_stmt->execute();
    $edu_result = $edu_stmt->get_result();
    
    if ($edu_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No education records available.', 0, 1);
    } else {
        // Education Table
        $pdf->SetFont('Helvetica', '', 12);
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Cell(90, 10, 'School Name', 1, 0, 'C', 1);
        $pdf->Cell(60, 10, 'Dates', 1, 0, 'C', 1);
        $pdf->Cell(0, 10, 'Description', 1, 1, 'C', 1);
        
        while ($edu = $edu_result->fetch_assoc()) {
            $pdf->Cell(90, 10, $edu['school_name'], 1);
            $pdf->Cell(60, 10, $edu['start_date'] . ' - ' . $edu['end_date'], 1);
            $pdf->MultiCell(0, 10, $edu['description'], 1);
        }
    }
    $pdf->Ln(10);

    // --- Skills Section ---
    $pdf->SetFont('Helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Skills', 0, 1);
    $pdf->SetFont('Helvetica', '', 12);
    
    $skills_stmt = $conn->prepare("SELECT * FROM skillss WHERE cv_id = ? AND deleted = 0");
    $skills_stmt->bind_param("i", $cv['id']);
    $skills_stmt->execute();
    $skills_result = $skills_stmt->get_result();
    
    if ($skills_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No skills records available.', 0, 1);
    } else {
        // Skills Table
        $pdf->SetFont('Helvetica', '', 12);
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Cell(0, 10, 'Skill', 1, 1, 'C', 1);
        
        while ($skill = $skills_result->fetch_assoc()) {
            $pdf->Cell(0, 10, $skill['skill_name'], 1);
        }
    }
    $pdf->Ln(10);

    // --- Languages Section ---
    $pdf->SetFont('Helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Languages', 0, 1);
    $pdf->SetFont('Helvetica', '', 12);
    
    $languages_stmt = $conn->prepare("SELECT * FROM languages WHERE cv_id = ? AND deleted = 0");
    $languages_stmt->bind_param("i", $cv['id']);
    $languages_stmt->execute();
    $languages_result = $languages_stmt->get_result();
    
    if ($languages_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No languages records available.', 0, 1);
    } else {
        // Languages Table
        $pdf->SetFont('Helvetica', '', 12);
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Cell(90, 10, 'Language', 1, 0, 'C', 1);
        $pdf->Cell(0, 10, 'Proficiency', 1, 1, 'C', 1);
        
        while ($language = $languages_result->fetch_assoc()) {
            $pdf->Cell(90, 10, $language['language_name'], 1);
            $pdf->Cell(0, 10, $language['proficiency_level'], 1, 1);
        }
    }
    $pdf->Ln(10);

    // --- Experience Section ---
    $pdf->SetFont('Helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Experience', 0, 1);
    $pdf->SetFont('Helvetica', '', 12);
    
    $exp_stmt = $conn->prepare("SELECT * FROM experience WHERE cv_id = ? AND deleted = 0");
    $exp_stmt->bind_param("i", $cv['id']);
    $exp_stmt->execute();
    $exp_result = $exp_stmt->get_result();
    
    if ($exp_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No experience records available.', 0, 1);
    } else {
        // Experience Table
        $pdf->SetFont('Helvetica', '', 12);
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Cell(60, 10, 'Job Title', 1, 0, 'C', 1);
        $pdf->Cell(80, 10, 'Company', 1, 0, 'C', 1);
        $pdf->Cell(40, 10, 'Dates', 1, 0, 'C', 1);
        $pdf->Cell(0, 10, 'Description', 1, 1, 'C', 1);
        
        while ($exp = $exp_result->fetch_assoc()) {
            $pdf->Cell(60, 10, $exp['job_title'], 1);
            $pdf->Cell(80, 10, $exp['company_name'], 1);
            $pdf->Cell(40, 10, $exp['start_date'] . ' - ' . $exp['end_date'], 1);
            $pdf->MultiCell(0, 10, $exp['description'], 1);
        }
    }
    $pdf->Ln(10);

    // --- Tasks Section ---
    $pdf->SetFont('Helvetica', 'B', 14);
    $pdf->Cell(0, 10, 'Tasks', 0, 1);
    $pdf->SetFont('Helvetica', '', 12);
    
    $tasks_stmt = $conn->prepare("SELECT * FROM tasks WHERE cv_id = ? AND deleted = 0");
    $tasks_stmt->bind_param("i", $cv['id']);
    $tasks_stmt->execute();
    $tasks_result = $tasks_stmt->get_result();
    
    if ($tasks_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No tasks records available.', 0, 1);
    } else {
        // Tasks Table
        $pdf->SetFont('Helvetica', '', 12);
        $pdf->SetFillColor(220, 220, 220);
        $pdf->Cell(60, 10, 'Task Name', 1, 0, 'C', 1);
        $pdf->Cell(80, 10, 'Deadline', 1, 0, 'C', 1);
        $pdf->Cell(0, 10, 'Description', 1, 1, 'C', 1);
        
        while ($task = $tasks_result->fetch_assoc()) {
            $pdf->Cell(60, 10, $task['task_name'], 1);
            $pdf->Cell(80, 10, $task['deadline'], 1);
            $pdf->MultiCell(0, 10, $task['description'], 1);
        }
    }
    $pdf->Ln(10);

    // Output the PDF
    $pdf->Output('D', 'CV_' . $cv['id'] . '.pdf');
}

?>
