<?php
// Include your database connection file
include('db.php');

// Start session
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // The ID of the logged-in user

// Get user information
$user_stmt = $conn->prepare("SELECT name, email, phone_number, address FROM users WHERE id = ?");
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Variable to control the display of the success message
$showConfirmation = false;
$cv_id = 0; // Variable to store the CV ID for download

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $description = $_POST['description'];
    $profile_picture = ""; // Initialize to empty

    // Handle file upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $profile_picture_name = $_FILES['profile_picture']['name'];
        $profile_picture_tmp = $_FILES['profile_picture']['tmp_name'];
        $profile_picture_size = $_FILES['profile_picture']['size'];

        // Define allowed file types and max file size (5MB)
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB limit

        if ($profile_picture_size > $max_size) {
            echo "File size is too large. Max 5MB.";
        } elseif (!in_array($_FILES['profile_picture']['type'], $allowed_types)) {
            echo "Invalid file type. Only JPG, PNG, and GIF allowed.";
        } else {
            // Generate a unique file name
            $file_extension = pathinfo($profile_picture_name, PATHINFO_EXTENSION);
            $unique_name = uniqid() . '.' . $file_extension;
            $upload_dir = 'uploads/profile_pictures/'; // Ensure this directory exists

            // Attempt to move the file to the server
            if (move_uploaded_file($profile_picture_tmp, $upload_dir . $unique_name)) {
                $profile_picture = $unique_name; // Save the file name
            } else {
                echo "Error uploading the file.";
            }
        }
    }
    
    // Begin transaction
    $conn->begin_transaction();
    try {
        // Insert CV record into the cvs table
        $stmt = $conn->prepare("INSERT INTO cvs (user_id, description, profile_picture) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $user_id, $description, $profile_picture);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting CV: " . $stmt->error);
        }

        // Get the last inserted CV ID
        $cv_id = $conn->insert_id;

        // Insert education records
        if (isset($_POST['school_name'])) {
            $stmt = $conn->prepare("INSERT INTO education (cv_id, school_name, start_date, end_date, description) VALUES (?, ?, ?, ?, ?)");
            foreach ($_POST['school_name'] as $index => $school_name) {
                $start_date = $_POST['start_date'][$index];
                $end_date = $_POST['end_date'][$index];
                $education_description = $_POST['education_description'][$index];
                $stmt->bind_param("issss", $cv_id, $school_name, $start_date, $end_date, $education_description);
                if (!$stmt->execute()) {
                    throw new Exception("Error inserting education: " . $stmt->error);
                }
            }
        }

        // Insert experience records
        if (isset($_POST['job_title'])) {
            $stmt = $conn->prepare("INSERT INTO experience (cv_id, job_title, company_name, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?)");
            foreach ($_POST['job_title'] as $index => $job_title) {
                $company_name = $_POST['company_name'][$index];
                $job_start_date = $_POST['job_start_date'][$index];
                $job_end_date = $_POST['job_end_date'][$index];
                $job_description = $_POST['job_description'][$index];
                $stmt->bind_param("isssss", $cv_id, $job_title, $company_name, $job_start_date, $job_end_date, $job_description);
                if (!$stmt->execute()) {
                    throw new Exception("Error inserting experience: " . $stmt->error);
                }
            }
        }

        // Insert task records
        if (isset($_POST['task_description'])) {
            $stmt = $conn->prepare("INSERT INTO task (cv_id, job_description) VALUES (?, ?)");
            foreach ($_POST['task_description'] as $task_description) {
                $stmt->bind_param("is", $cv_id, $task_description);
                if (!$stmt->execute()) {
                    throw new Exception("Error inserting task: " . $stmt->error);
                }
            }
        }

         // Insert skills records
          if (isset($_POST['skill_name'])) {
          $stmt = $conn->prepare("INSERT INTO skillss (cv_id, skill_name) VALUES (?, ?)");
         foreach ($_POST['skill_name'] as $index => $skill_name) {
         // Use the cv_id which was just inserted
         $stmt->bind_param("is", $cv_id, $skill_name);
          if (!$stmt->execute()) {
            throw new Exception("Error inserting skill: " . $stmt->error);
        }
    }
}


        // Insert languages records
        if (isset($_POST['language_name'])) {
            $stmt = $conn->prepare("INSERT INTO languages (cv_id, language_name, proficiency_level) VALUES (?, ?, ?)");
            foreach ($_POST['language_name'] as $index => $language_name) {
                $proficiency_level = $_POST['proficiency_level'][$index];
                $stmt->bind_param("iss", $cv_id, $language_name, $proficiency_level);
                if (!$stmt->execute()) {
                    throw new Exception("Error inserting language: " . $stmt->error);
                }
            }
            
        }

        // Insert hobbies records
        if (isset($_POST['hobby_name'])) {
            $stmt = $conn->prepare("INSERT INTO hobbies (cv_id, hobby_name) VALUES (?, ?)");
            foreach ($_POST['hobby_name'] as $hobby_name) {
                $stmt->bind_param("is", $cv_id, $hobby_name);
                if (!$stmt->execute()) {
                    throw new Exception("Error inserting hobby: " . $stmt->error);
                }
            }
        }

        // Commit the transaction
        $conn->commit();
        
        // Show confirmation message
        $showConfirmation = true; // Set flag to show confirmation
    } catch (Exception $e) {
        // Rollback the transaction on error
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
    // Validate Education Dates
if (isset($_POST['school_name'])) {
    foreach ($_POST['school_name'] as $index => $school_name) {
        $start_date = $_POST['start_date'][$index];
        $end_date = $_POST['end_date'][$index];
        
        if (strtotime($start_date) > strtotime($end_date)) {
            echo "End Date for Education cannot be earlier than Start Date.";
            exit();
        }
        
        // Insert into the database if valid
        $stmt = $conn->prepare("INSERT INTO education (cv_id, school_name, start_date, end_date, description) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issss", $cv_id, $school_name, $start_date, $end_date, $_POST['education_description'][$index]);
        $stmt->execute();
    }
}

// Validate Experience Dates
if (isset($_POST['job_title'])) {
    foreach ($_POST['job_title'] as $index => $job_title) {
        $start_date = $_POST['job_start_date'][$index];
        $end_date = $_POST['job_end_date'][$index];
        
        if (strtotime($start_date) > strtotime($end_date)) {
            echo "End Date for Experience cannot be earlier than Start Date.";
            exit();
        }
        
        // Insert into the database if valid
        $stmt = $conn->prepare("INSERT INTO experience (cv_id, job_title, company_name, start_date, end_date, description) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $cv_id, $job_title, $_POST['company_name'][$index], $start_date, $end_date, $_POST['job_description'][$index]);
        $stmt->execute();
    }
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create CV</title>
    <!-- Bootstrap 4 CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
<style>
    .container {
        max-width: 900px;
        margin-top: 30px;
    }
    .confirmation-message {
        background-color: #f9f9f9;
        padding: 20px;
        margin-bottom: 20px;
        border: 1px solid #27ae60;
        border-radius: 4px;
        color: #27ae60;
        text-align: center;
    }
    .form-section {
        margin-bottom: 20px;
    }
    .form-section button {
        margin-top: 10px;
    }
    /* Custom styling for side1 (30%) and side2 (70%) */
    .side1 {
        width: 30%;
        padding-right: 20px;
        background-color: #000000; /* Blue background */
        padding: 20px;
        color: #FA8072;

    }
    .side2 {
        width: 70%;
        background-color: #FA8072;
    }

        .image-placeholder {
            width: 150px;
            height: 150px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            background-color: #f5f5f5;
            border-radius: 50%; /* Makes it a circle */
            overflow: hidden; /* Ensures image stays within circle */
        }

        .image-placeholder img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
            aspect-ratio: 1 / 1;

            border-radius: 50%; /* Ensures the image is also a circle */
        }


        .file-input {
            display: none;
        }
</style>

    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center mb-4">Create Your CV</h1>
    
    <?php if ($showConfirmation): ?>
        <div class="confirmation-message">
            <p>Your CV has been successfully created! You can now view or download your CV.</p>
            <!-- Add a button to download the CV as PDF -->
            <a href="generate_pdf.php?cv_id=<?php echo $cv_id; ?>" class="btn btn-primary">Download CV as PDF</a>
            <!-- Button to delete the CV -->
            <a href="delete_cv.php?cv_id=<?php echo $cv_id; ?>" class="btn btn-danger ml-2">Delete CV</a>
            <a href="view_cvs.php?cv_id=<?php echo $cv_id; ?>" class="btn btn-danger ml-2">View CV</a>
            


         
          
        </div>
    <?php endif; ?>
    

    <form method="POST" enctype="multipart/form-data">
        <div class="row">
            <!-- Side 1 (30% width) -->
            <div class="col-md-4 side1">
                <!-- Personal Information Section -->                    
                <div class="form-group">

    <!-- Hidden file input -->
    <input type="file" class="form-control-file" name="profile_picture" id="profile_picture" style="display:none;" onchange="previewImage(event)">
    
    <!-- Image preview placeholder -->
    <div class="row">
        <!-- Placeholder div that acts as the input trigger -->
        <div class="image-placeholder" onclick="document.getElementById('profile_picture').click();" style="cursor: pointer; text-align: center;">
            <img id="uploadedImage" src="" alt="Uploaded Image" style="display:none; max-width: 100%; height: auto;">
            <span id="placeholderText">Click to upload an image</span>
        </div>
    </div>
</div>

                <div class="form-section">
                    <label for="name">Name</label>
                    <input type="text" class="form-control"  id="name" name="name" value="<?php echo $user['name']; ?>" required>
                </div>

                <div class="form-section">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                </div>

                <div class="form-section">
                    <label for="phone_number">Phone Number</label>
                    <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo $user['phone_number']; ?>" required>
                </div>

                <div class="form-section">
                    <label for="address">Address</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php echo $user['address']; ?>" required>
                </div>

                <div id="skillss-section">
                    <div class="form-section">
                        <label>Skill Name</label>
                        <input type="text" class="form-control" name="skill_name[]" placeholder="Skill name">
                        <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>                
                        <button type="button" class="btn btn-primary mt-2" onclick="addSkillSection()">Add Skill</button>
                    </div>
                </div>
                <!-- Languages Section -->
                <div id="languages-section">
                    <div class="form-section">
                        <label>Language Name</label>
                        <input type="text" class="form-control" name="language_name[]" placeholder="Language name">
                        <label>Proficiency Level</label>
                        <select class="form-control" name="proficiency_level[]">
                            <option value="Beginner">Beginner</option>
                            <option value="Intermediate">Intermediate</option>
                            <option value="Advanced">Advanced</option>
                            <option value="Fluent">Fluent</option>
                        </select>
                        <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>  
        
                        <button type="button" class="btn btn-primary mt-2" onclick="addLanguageSection()">Add Language</button>

                    </div>
                </div>
              
                <!-- Hobbies Section -->
                <div id="hobbies-section">
                    <div class="form-section">
                        <label>Hobby Name</label>
                        <input type="text" class="form-control" name="hobby_name[]" placeholder="Hobby name">
                        <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>                
                        <button type="button" class="btn btn-primary mt-2" onclick="addHobbySection()">Add Hobby</button>
                    </div>
                </div>

            </div>

            <!-- Side 2 (70% width) -->
            <div class="col-md-8 side2">
                <div class="form-group">
                    <label for="description">Profile Description</label>
                    <textarea class="form-control" name="description" id="description" rows="4"></textarea>
                </div>

                <!-- Education Section -->
                <div id="education-section">
                    <div class="form-section">
                        <label>School Name</label>
                        <input type="text" class="form-control" name="school_name[]" placeholder="School name">
                        <label>Start Date</label>
                        <input type="date" class="form-control" name="start_date[]">
                        <label>End Date</label>
                        <input type="date" class="form-control" name="end_date[]">
                        <label>Description</label>
                        <textarea class="form-control" name="education_description[]" rows="3"></textarea>
                        <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>              
                        <button type="button" class="btn btn-primary mt-2" onclick="addEducationSection()">Add Education</button>
                    </div>
                </div>


                <!-- Experience Section -->
                <div id="experience-section">
                    <div class="form-section">
                        <label>Job Title</label>
                        <input type="text" class="form-control" name="job_title[]" placeholder="Job title">
                        <label>Company Name</label>
                        <input type="text" class="form-control" name="company_name[]" placeholder="Company name">
                        <label>Start Date</label>
                        <input type="date" class="form-control" name="job_start_date[]">
                        <label>End Date</label>
                        <input type="date" class="form-control" name="job_end_date[]">
                        <label>Job Description</label>
                        <textarea class="form-control" name="job_description[]" rows="3"></textarea>
                        <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>               
                        <button type="button" class="btn btn-primary mt-2" onclick="addExperienceSection()">Add Experience</button>
                    </div>
                </div>


                <!-- Skills Section -->



                <!-- Task Section -->
                <div id="task-section">
                    <div class="form-section">
                        <label>Task Description</label>
                        <textarea class="form-control" name="task_description[]" rows="3"></textarea>
                        <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>                
                        <button type="button" class="btn btn-primary mt-2" onclick="addTaskSection()">Add Task</button>
                    </div>
                </div>


            </div>
        </div>

        <div class="form-group d-flex justify-content-between mt-4">
    <button type="submit" class="btn btn-success flex-grow-1">Save CV</button>
    <button type="button" class="btn btn-secondary ml-2" onclick="location.href='../index.php'">Go Back</button>
        </div>
    </form>
</div>

<!-- Bootstrap 4 JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    function addLanguageSection() {
        const languagesSection = document.getElementById('languages-section');
        const languageDiv = document.createElement('div');
        languageDiv.className = 'form-section';
        languageDiv.innerHTML = `
            <label>Language Name</label>
            <input type="text" class="form-control" name="language_name[]" placeholder="Language name">
            <label>Proficiency Level</label>
            <select class="form-control" name="proficiency_level[]">
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
                <option value="Fluent">Fluent</option>
            </select>
            <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>
        `;
        languagesSection.appendChild(languageDiv);
    }

    function addHobbySection() {
        const hobbiesSection = document.getElementById('hobbies-section');
        const hobbyDiv = document.createElement('div');
        hobbyDiv.className = 'form-section';
        hobbyDiv.innerHTML = `
            <label>Hobby Name</label>
            <input type="text" class="form-control" name="hobby_name[]" placeholder="Hobby name">
            <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>
        `;
        hobbiesSection.appendChild(hobbyDiv);
    }

  
    
    function addEducationSection() {
        const educationSection = document.getElementById('education-section');
        const educationDiv = document.createElement('div');
        educationDiv.className = 'form-section';
        educationDiv.innerHTML = `
            <label>School Name</label>
            <input type="text" class="form-control" name="school_name[]" placeholder="School name">
            <label>Start Date</label>
            <input type="date" class="form-control" name="start_date[]">
            <label>End Date</label>
            <input type="date" class="form-control" name="end_date[]">
            <label>Description</label>
            <textarea class="form-control" name="education_description[]" rows="3"></textarea>
            <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>
        `;
        educationSection.appendChild(educationDiv);
    }

    function addExperienceSection() {
        const experienceSection = document.getElementById('experience-section');
        const experienceDiv = document.createElement('div');
        experienceDiv.className = 'form-section';
        experienceDiv.innerHTML = `
            <label>Job Title</label>
            <input type="text" class="form-control" name="job_title[]" placeholder="Job title">
            <label>Company Name</label>
            <input type="text" class="form-control" name="company_name[]" placeholder="Company name">
            <label>Start Date</label>
            <input type="date" class="form-control" name="job_start_date[]">
            <label>End Date</label>
            <input type="date" class="form-control" name="job_end_date[]">
            <label>Job Description</label>
            <textarea class="form-control" name="job_description[]" rows="3"></textarea>
            <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>
        `;
        experienceSection.appendChild(experienceDiv);
    }



    function addSkillSection() {
        const skillsSection = document.getElementById('skillss-section');
        const skillDiv = document.createElement('div');
        skillDiv.className = 'form-section';
        skillDiv.innerHTML = `
            <label>Skill Name</label>
            <input type="text" class="form-control" name="skill_name[]" placeholder="Skill name">
            <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>
        `;
        skillsSection.appendChild(skillDiv);
    }

    function addTaskSection() {
        const taskSection = document.getElementById('task-section');
        const taskDiv = document.createElement('div');
        taskDiv.className = 'form-section';
        taskDiv.innerHTML = `
            <label>Task Description</label>
            <textarea class="form-control" name="task_description[]" rows="3"></textarea>
            <button type="button" class="btn btn-danger mt-2" onclick="removeSection(this)">Remove</button>
        `;
        taskSection.appendChild(taskDiv);
    }

    function removeSection(button) {
        button.closest('.form-section').remove();
    }

    function previewImage(event) {
        const input = event.target;
        const reader = new FileReader();
        reader.onload = function() {
            const uploadedImage = document.getElementById('uploadedImage');
            const placeholderText = document.getElementById('placeholderText');
            uploadedImage.src = reader.result;
            uploadedImage.style.display = 'block';
            placeholderText.style.display = 'none';
        };
        reader.readAsDataURL(input.files[0]);
    }
</script>

</body>
</html>









