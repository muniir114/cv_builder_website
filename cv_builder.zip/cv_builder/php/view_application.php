<?php
session_start();
include 'db.php';

// Ensure the user is logged in (check for admin role)
if (isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Get application ID from URL
if (isset($_GET['id'])) {
    $application_id = $_GET['id'];

    // Fetch CV and user data from the database
    $stmt = $conn->prepare("SELECT * FROM cvs WHERE id = ?");
    $stmt->bind_param('i', $application_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the query returned a result
    if ($result->num_rows == 1) {
        $cv = $result->fetch_assoc();
        
        // Now fetch user data based on user_id from cvs table
        $user_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $user_stmt->bind_param('i', $cv['user_id']);
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        
        if ($user_result->num_rows == 1) {
            $application = $user_result->fetch_assoc();
        } else {
            $error_message = "No user data found for this application.";
        }

        

// Check if the file actually exists
$profile_picture_path = 'uploads/profile_pictures/' . $cv['profile_picture'];
$image_src = '';

if (!empty($cv['profile_picture']) && file_exists($profile_picture_path)) {
    $image_src = $profile_picture_path;
} else {
    // Fallback to a default profile picture
    $image_src = 'https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-High-Quality-Image.png';
}

    

        // Fetch Skills
        $skills_stmt = $conn->prepare("SELECT * FROM skillss WHERE cv_id = ?");
        $skills_stmt->bind_param('i', $cv['id']);
        $skills_stmt->execute();
        $skills_result = $skills_stmt->get_result();
        // Fetch Education
$education_stmt = $conn->prepare("SELECT * FROM education WHERE cv_id = ?");
$education_stmt->bind_param('i', $cv['id']);
$education_stmt->execute();
$education_result = $education_stmt->get_result();


        // Fetch Experience
        $experience_stmt = $conn->prepare("SELECT * FROM experience WHERE cv_id = ?");
        $experience_stmt->bind_param('i', $cv['id']);
        $experience_stmt->execute();
        $experience_result = $experience_stmt->get_result();

        // Fetch Tasks
        $task_stmt = $conn->prepare("SELECT * FROM task WHERE cv_id = ?");
        $task_stmt->bind_param('i', $cv['id']);
        $task_stmt->execute();
        $task_result = $task_stmt->get_result();

        // Fetch Hobbies
        $hobbies_stmt = $conn->prepare("SELECT * FROM hobbies WHERE cv_id = ?");
        $hobbies_stmt->bind_param('i', $cv['id']);
        $hobbies_stmt->execute();
        $hobbies_result = $hobbies_stmt->get_result();

        // Fetch Languages
        $languages_stmt = $conn->prepare("SELECT * FROM languages WHERE cv_id = ?");
        $languages_stmt->bind_param('i', $cv['id']);
        $languages_stmt->execute();
        $languages_result = $languages_stmt->get_result();
    } else {
        $error_message = "No application data found for this ID.";
    }
} else {
    $error_message = "No application ID provided!";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Application</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .application-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .btn-back {
            margin-top: 20px;
        }

        .cv-section-title {
            margin-top: 20px;
            font-size: 1.5rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center text-primary mb-4">View Application Details</h2>

    <!-- Error Message (if application not found) -->
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>

    <!-- Application Details -->
    <div class="application-container">
        <?php if (isset($application)): ?>
            <!-- Profile Picture -->
            <!-- Profile Picture Section -->
<!-- Profile Picture Section -->
<div class="text-center">
    <img src="<?php echo htmlspecialchars($image_src); ?>" alt="Profile Picture" style="width: 200px; height: 200px;">
</div>


</div>


            <h4 class="text-center mb-4">Applicant Information</h4>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($application['name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($application['email']); ?></p>
            <p><strong>Phone:</strong> <?php echo htmlspecialchars($application['phone_number']); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($application['address']); ?></p>

            <!-- CV Details -->
            <h5 class="mt-4">CV Details:</h5>
            <p><strong>Description:</strong> <?php echo htmlspecialchars($cv['description']); ?></p>
            
            <!-- Skills Section -->
            <div class="cv-section-title">Skills</div>
            <?php if ($skills_result->num_rows > 0): ?>
                <ul>
                    <?php while ($skill = $skills_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($skill['skill_name']); ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No skills listed.</p>
            <?php endif; ?>
            <!-- Education Section -->
<div class="cv-section-title">Education</div>
<?php if ($education_result->num_rows > 0): ?>
    <ul>
        <?php while ($education = $education_result->fetch_assoc()): ?>
            <li>
                <strong><?php echo htmlspecialchars($education['school_name']); ?></strong> - 
                <?php echo htmlspecialchars($education['department']); ?> 
                (<?php echo htmlspecialchars($education['start_date']); ?> to <?php echo htmlspecialchars($education['end_date'] ?: 'Present'); ?>)
                <p><?php echo nl2br(htmlspecialchars($education['description'])); ?></p>
            </li>
        <?php endwhile; ?>
    </ul>
<?php else: ?>
    <p>No education listed.</p>
<?php endif; ?>


            <!-- Experience Section -->
            <div class="cv-section-title">Experience</div>
            <?php if ($experience_result->num_rows > 0): ?>
                <ul>
                    <?php while ($experience = $experience_result->fetch_assoc()): ?>
                        <li><strong><?php echo htmlspecialchars($experience['job_title']); ?></strong> at <?php echo htmlspecialchars($experience['company_name']); ?>
                            (<?php echo htmlspecialchars($experience['start_date']); ?> to <?php echo htmlspecialchars($experience['end_date'] ?: 'Present'); ?>)
                            <p><?php echo nl2br(htmlspecialchars($experience['description'])); ?></p>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No experience listed.</p>
            <?php endif; ?>

            <!-- Tasks Section -->
            <div class="cv-section-title">Tasks</div>
            <?php if ($task_result->num_rows > 0): ?>
                <ul>
                    <?php while ($task = $task_result->fetch_assoc()): ?>
                        <li><?php echo nl2br(htmlspecialchars($task['job_description'])); ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No tasks listed.</p>
            <?php endif; ?>

            <!-- Hobbies Section -->
            <div class="cv-section-title">Hobbies</div>
            <?php if ($hobbies_result->num_rows > 0): ?>
                <ul>
                    <?php while ($hobby = $hobbies_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($hobby['hobby_name']); ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No hobbies listed.</p>
            <?php endif; ?>

            <!-- Languages Section -->
            <div class="cv-section-title">Languages</div>
            <?php if ($languages_result->num_rows > 0): ?>
                <ul>
                    <?php while ($language = $languages_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($language['language_name']); ?> (<?php echo htmlspecialchars($language['proficiency_level']); ?>)</li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No languages listed.</p>
            <?php endif; ?>
            
        <?php endif; ?>

        <!-- Back to Admin Dashboard -->
        <a href="admin.php" class="btn btn-secondary btn-back">Back to Admin Dashboard</a>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>


