<?php
// Include database connection
include 'db.php';

// Fetch CV ID from the URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $cv_id = (int)$_GET['id'];

    // Fetch CV data
    $cv_query = "SELECT * FROM cvs WHERE id = $cv_id";
    $cv_result = mysqli_query($conn, $cv_query);

    if (mysqli_num_rows($cv_result) == 0) {
        echo "No CV found with this ID.";
        exit;
    }
    $cv_data = mysqli_fetch_assoc($cv_result);

    // Fetch user data
    $user_query = "SELECT * FROM users WHERE id = " . $cv_data['user_id'];
    $user_result = mysqli_query($conn, $user_query);
    if (mysqli_num_rows($user_result) == 0) {
        echo "No user found for this CV.";
        exit;
    }
    $user_data = mysqli_fetch_assoc($user_result);
} else {
    echo "No CV ID provided.";
    exit;
}

// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Personal Information
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $cv_description = mysqli_real_escape_string($conn, $_POST['cv_description']);
    $profile_picture = $_FILES['profile_picture']['name'] ? $_FILES['profile_picture']['name'] : $cv_data['profile_picture'];

    // Handle Profile Picture Upload
    if ($_FILES['profile_picture']['name']) {
        move_uploaded_file($_FILES['profile_picture']['tmp_name'], "uploads/" . $profile_picture);
    }

    // Update CV Data
    $update_cv = "UPDATE cvs SET description = '$cv_description', profile_picture = '$profile_picture' WHERE id = $cv_id";
    mysqli_query($conn, $update_cv);

    // Update Skills
    mysqli_query($conn, "DELETE FROM skillss WHERE cv_id = $cv_id");
    if (isset($_POST['skill_name'])) {
        foreach ($_POST['skill_name'] as $skill) {
            if (!empty($skill)) {
                $skill = mysqli_real_escape_string($conn, $skill);
                mysqli_query($conn, "INSERT INTO skillss (cv_id, skill_name) VALUES ($cv_id, '$skill')");
            }
        }
    }

    // Update Education
    mysqli_query($conn, "DELETE FROM education WHERE cv_id = $cv_id");
    if (isset($_POST['education'])) {
        foreach ($_POST['education'] as $key => $school_name) {
            if (!empty($school_name)) {
                $school_name = mysqli_real_escape_string($conn, $school_name);
                $start_date = $_POST['education_start'][$key];
                $end_date = $_POST['education_end'][$key];
                $description = mysqli_real_escape_string($conn, $_POST['education_description'][$key]);
                mysqli_query($conn, "INSERT INTO education (cv_id, school_name, start_date, end_date, description) VALUES ($cv_id, '$school_name', '$start_date', '$end_date', '$description')");
            }
        }
    }

    // Update Experience
    mysqli_query($conn, "DELETE FROM experience WHERE cv_id = $cv_id");
    if (isset($_POST['experience_title'])) {
        foreach ($_POST['experience_title'] as $key => $job_title) {
            if (!empty($job_title)) {
                $job_title = mysqli_real_escape_string($conn, $job_title);
                $company_name = mysqli_real_escape_string($conn, $_POST['experience_company'][$key]);
                $start_date = $_POST['experience_start'][$key];
                $end_date = $_POST['experience_end'][$key];
                $description = mysqli_real_escape_string($conn, $_POST['experience_description'][$key]);
                mysqli_query($conn, "INSERT INTO experience (cv_id, job_title, company_name, start_date, end_date, description) VALUES ($cv_id, '$job_title', '$company_name', '$start_date', '$end_date', '$description')");
            }
        }
    }

    // Update Tasks
    mysqli_query($conn, "DELETE FROM task WHERE cv_id = $cv_id");
    if (isset($_POST['task_description'])) {
        foreach ($_POST['task_description'] as $task_description) {
            if (!empty($task_description)) {
                $task_description = mysqli_real_escape_string($conn, $task_description);
                mysqli_query($conn, "INSERT INTO task (cv_id, job_description) VALUES ($cv_id, '$task_description')");
            }
        }
    }

    // Update Languages
    mysqli_query($conn, "DELETE FROM languages WHERE cv_id = $cv_id");
    if (isset($_POST['language_name'])) {
        foreach ($_POST['language_name'] as $key => $language_name) {
            if (!empty($language_name)) {
                $language_name = mysqli_real_escape_string($conn, $language_name);
                $proficiency = mysqli_real_escape_string($conn, $_POST['language_proficiency'][$key]);
                mysqli_query($conn, "INSERT INTO languages (cv_id, language_name, proficiency_level) VALUES ($cv_id, '$language_name', '$proficiency')");
            }
        }
    }

    // Update Hobbies
    mysqli_query($conn, "DELETE FROM hobbies WHERE cv_id = $cv_id");
    if (isset($_POST['hobby_name'])) {
        foreach ($_POST['hobby_name'] as $hobby_name) {
            if (!empty($hobby_name)) {
                $hobby_name = mysqli_real_escape_string($conn, $hobby_name);
                mysqli_query($conn, "INSERT INTO hobbies (cv_id, hobby_name) VALUES ($cv_id, '$hobby_name')");
            }
        }
    }

    // Redirect after update
    header("Location: view_cvs.php?id=$cv_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Your CV</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
        }
        .container {
            margin-top: 50px;
        }
        .form-section {
            margin-bottom: 20px;
        }
        .form-control {
            border-radius: 5px;
            padding: 10px;
            font-size: 16px;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .form-section input, .form-section textarea {
            margin-bottom: 10px;
        }
        .profile-img {
            width: 150px;
            height: 150px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center mb-4">Edit Your CV</h1>

    <form method="POST" enctype="multipart/form-data">
        <!-- Personal Information Section -->
        <div class="form-group">
    <label for="profile_picture">Profile Picture</label><br>
    
    <?php
    // Check if a profile picture exists and if it's valid
    $profile_picture_path = 'uploads/' . $cv_data['profile_picture'];
    if (!empty($cv_data['profile_picture']) && file_exists($profile_picture_path)) {
        // Display the uploaded profile picture
        echo '<img src="' . $profile_picture_path . '" class="profile-img mb-3" alt="Profile Picture">';
    } else {
        // Display the default profile picture if none is uploaded
        echo '<img src="https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-High-Quality-Image.png" class="profile-img mb-3" alt="Default Profile Picture">';
    }
    ?>

   
</div>

        <div class="form-section">
            <h3>Personal Information</h3>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
            </div>

            <div class="form-group">
                <label for="phone_number">Phone Number</label>
                <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($user_data['phone_number']); ?>" required>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($user_data['address']); ?>" required>
            </div>
        </div>

        <!-- CV Information Section -->
        <div class="form-section">
            <h3>CV Information</h3>
            <div class="form-group">
                <label for="cv_description">CV Description</label>
                <textarea class="form-control" id="cv_description" name="cv_description" rows="4"><?php echo htmlspecialchars($cv_data['description']); ?></textarea>
            </div>

            

        <!-- Skills Section -->
        <div class="form-section">
            <h3>Skills</h3>
            <?php 
            // Fetch skills from the database
            $skills_query = "SELECT * FROM skillss WHERE cv_id = $cv_id";
            $skills_result = mysqli_query($conn, $skills_query);
            while ($skill = mysqli_fetch_assoc($skills_result)) {
                echo '
                <div class="form-group">
                    <input type="text" class="form-control" name="skill_name[]" value="' . htmlspecialchars($skill['skill_name']) . '" placeholder="Skill name" required>
                </div>';
            }
            ?>
            <button type="button" class="btn btn-primary" onclick="addSkillSection()">Add Skill</button>
        </div>

        <!-- Education Section -->
        <div class="form-section">
            <h3>Education</h3>
            <?php 
            // Fetch education info from the database
            $education_query = "SELECT * FROM education WHERE cv_id = $cv_id";
            $education_result = mysqli_query($conn, $education_query);
            while ($education = mysqli_fetch_assoc($education_result)) {
                echo '
                <div class="form-group">
                    <input type="text" class="form-control" name="education[]" value="' . htmlspecialchars($education['school_name']) . '" placeholder="School Name">
                    <input type="date" class="form-control" name="education_start[]" value="' . $education['start_date'] . '" placeholder="Start Date">
                    <input type="date" class="form-control" name="education_end[]" value="' . $education['end_date'] . '" placeholder="End Date">
                    <textarea class="form-control" name="education_description[]" placeholder="Description">' . htmlspecialchars($education['description']) . '</textarea>
                </div>';
            }
            ?>
            <button type="button" class="btn btn-primary" onclick="addEducationSection()">Add Education</button>
        </div>

        <!-- Experience Section -->
        <div class="form-section">
            <h3>Experience</h3>
            <?php 
            // Fetch experience info from the database
            $experience_query = "SELECT * FROM experience WHERE cv_id = $cv_id";
            $experience_result = mysqli_query($conn, $experience_query);
            while ($experience = mysqli_fetch_assoc($experience_result)) {
                echo '
                <div class="form-group">
                    <input type="text" class="form-control" name="experience_title[]" value="' . htmlspecialchars($experience['job_title']) . '" placeholder="Job Title">
                    <input type="text" class="form-control" name="experience_company[]" value="' . htmlspecialchars($experience['company_name']) . '" placeholder="Company Name">
                    <input type="date" class="form-control" name="experience_start[]" value="' . $experience['start_date'] . '" placeholder="Start Date">
                    <input type="date" class="form-control" name="experience_end[]" value="' . $experience['end_date'] . '" placeholder="End Date">
                    <textarea class="form-control" name="experience_description[]" placeholder="Job Description">' . htmlspecialchars($experience['description']) . '</textarea>
                </div>';
            }
            ?>
            <button type="button" class="btn btn-primary" onclick="addExperienceSection()">Add Experience</button>
        </div>

        <!-- Tasks Section -->
        <div class="form-section">
            <h3>Tasks</h3>
            <?php 
            // Fetch tasks info from the database
            $tasks_query = "SELECT * FROM task WHERE cv_id = $cv_id";
            $tasks_result = mysqli_query($conn, $tasks_query);
            while ($task = mysqli_fetch_assoc($tasks_result)) {
                echo '
                <div class="form-group">
                    <textarea class="form-control" name="task_description[]" placeholder="Task Description">' . htmlspecialchars($task['job_description']) . '</textarea>
                </div>';
            }
            ?>
            <button type="button" class="btn btn-primary" onclick="addTaskSection()">Add Task</button>
        </div>

        <!-- Languages Section -->
        <div class="form-section">
            <h3>Languages</h3>
            <?php 
            // Fetch languages info from the database
            $languages_query = "SELECT * FROM languages WHERE cv_id = $cv_id";
            $languages_result = mysqli_query($conn, $languages_query);
            while ($language = mysqli_fetch_assoc($languages_result)) {
                echo '
                <div class="form-group">
                    <input type="text" class="form-control" name="language_name[]" value="' . htmlspecialchars($language['language_name']) . '" placeholder="Language Name">
                    <select class="form-control" name="language_proficiency[]">
                        <option value="Beginner" ' . ($language['proficiency_level'] == 'Beginner' ? 'selected' : '') . '>Beginner</option>
                        <option value="Intermediate" ' . ($language['proficiency_level'] == 'Intermediate' ? 'selected' : '') . '>Intermediate</option>
                        <option value="Advanced" ' . ($language['proficiency_level'] == 'Advanced' ? 'selected' : '') . '>Advanced</option>
                        <option value="Fluent" ' . ($language['proficiency_level'] == 'Fluent' ? 'selected' : '') . '>Fluent</option>
                    </select>
                </div>';
            }
            ?>
            <button type="button" class="btn btn-primary" onclick="addLanguageSection()">Add Language</button>
        </div>

        <!-- Hobbies Section -->
        <div class="form-section">
            <h3>Hobbies</h3>
            <?php 
            // Fetch hobbies info from the database
            $hobbies_query = "SELECT * FROM hobbies WHERE cv_id = $cv_id";
            $hobbies_result = mysqli_query($conn, $hobbies_query);
            while ($hobby = mysqli_fetch_assoc($hobbies_result)) {
                echo '
                <div class="form-group">
                    <input type="text" class="form-control" name="hobby_name[]" value="' . htmlspecialchars($hobby['hobby_name']) . '" placeholder="Hobby Name">
                </div>';
            }
            ?>
            <button type="button" class="btn btn-primary" onclick="addHobbySection()">Add Hobby</button>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-success mt-3">Update CV</button>
        <!-- Go Back Button -->
       <a href="view_cvs.php?id=<?php echo $cv_id; ?>" class="btn btn-success mt-3">Go Back</a>


    </form>
</div>

<script>
    // Add dynamic sections for Skills, Education, Experience, Tasks, Languages, and Hobbies
    function addSkillSection() {
        // Add new skill input dynamically
    }

    function addEducationSection() {
        // Add new education section dynamically
    }

    function addExperienceSection() {
        // Add new experience section dynamically
    }

    function addTaskSection() {
        // Add new task section dynamically
    }

    function addLanguageSection() {
        // Add new language section dynamically
    }

    function addHobbySection() {
        // Add new hobby section dynamically
    }
   // Function to preview the uploaded image
function previewImage() {
    var file = document.getElementById("profile_picture").files[0];
    var reader = new FileReader();

    reader.onload = function(e) {
        // Display the image in the placeholder
        document.getElementById("uploadedImage").src = e.target.result;
        document.getElementById("uploadedImage").style.display = "block";  // Show the image
        document.getElementById("placeholderText").style.display = "none";  // Hide the placeholder text
    }

    if (file) {
        reader.readAsDataURL(file);
    }
}
</script>

</body>
</html>
