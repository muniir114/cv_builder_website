<?php
session_start();
include 'db.php';

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get the logged-in user's ID
$user_id = $_SESSION['user_id'];

// Fetch the CV data from the database
$stmt = $conn->prepare("SELECT * FROM cvs WHERE user_id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if the user has a CV saved
if ($result->num_rows > 0) {
    $cv = $result->fetch_assoc();
    
    // Fetch user information from the users table
    $user_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $user_stmt->bind_param('i', $user_id);
    $user_stmt->execute();
    $user_result = $user_stmt->get_result();

    // If user data is found
    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc();
    }

    // Fetch the profile picture
    $profile_picture_path = 'uploads/profile_pictures/' . $cv['profile_picture'];
    $image_src = '';

    if (!empty($cv['profile_picture']) && file_exists($profile_picture_path)) {
        $image_src = $profile_picture_path;
    } else {
        // Fallback to a default profile picture
        $image_src = 'https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-High-Quality-Image.png';
    }
    
    // Fetch Skills
    $skills_stmt = $conn->prepare("SELECT * FROM skillss WHERE cv_id = ?");
    $skills_stmt->bind_param('i', $cv['id']);
    $skills_stmt->execute();
    $skills_result = $skills_stmt->get_result();
    // Fetch Education
$education_stmt = $conn->prepare("SELECT * FROM education WHERE cv_id = ?");
$education_stmt->bind_param('i', $cv['id']);
$education_stmt->execute();
$education_result = $education_stmt->get_result();

    

    // Fetch Experience
    $experience_stmt = $conn->prepare("SELECT * FROM experience WHERE cv_id = ?");
    $experience_stmt->bind_param('i', $cv['id']);
    $experience_stmt->execute();
    $experience_result = $experience_stmt->get_result();

    // Fetch Tasks
    $task_stmt = $conn->prepare("SELECT * FROM task WHERE cv_id = ?");
    $task_stmt->bind_param('i', $cv['id']);
    $task_stmt->execute();
    $task_result = $task_stmt->get_result();

    // Fetch Hobbies
    $hobbies_stmt = $conn->prepare("SELECT * FROM hobbies WHERE cv_id = ?");
    $hobbies_stmt->bind_param('i', $cv['id']);
    $hobbies_stmt->execute();
    $hobbies_result = $hobbies_stmt->get_result();

    // Fetch Languages
    $languages_stmt = $conn->prepare("SELECT * FROM languages WHERE cv_id = ?");
    $languages_stmt->bind_param('i', $cv['id']);
    $languages_stmt->execute();
    $languages_result = $languages_stmt->get_result();

} else {
    $error_message = "No CV found for this user.";
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process form data...

    // After processing, redirect to avoid resubmission
    header('Location: ' . $_SERVER['REQUEST_URI']); // Or redirect to a different page
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View CV</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .cv-section-title {
            margin-top: 20px;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .btn-back {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center text-primary mb-4">Your CV</h2>

    <!-- Error Message (if no CV found) -->
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>

    <!-- Display CV Details -->
    <div class="cv-container">
        <?php if (isset($cv)): ?>
            <!-- Personal Information -->
            <h4 class="text-center"><?php echo htmlspecialchars($user['name']); ?>'s CV</h4>

            <div class="row">
                <div class="col-12 text-center">
                    <img src="<?php echo htmlspecialchars($image_src); ?>" alt="Profile Picture" class="img-fluid rounded-circle" style="width: 200px; height: 200px;">
                </div>
            </div>
            <div class="mt-4">
                <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone_number']); ?></p>
                <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address']); ?></p>
            </div>

            <!-- CV Details -->
            <h5 class="mt-4">Description:</h5>
            <p><?php echo nl2br(htmlspecialchars($cv['description'])); ?></p>
            
            <!-- Skills Section -->
            <div class="cv-section-title">Skills</div>
            <?php if ($skills_result->num_rows > 0): ?>
                <ul>
                    <?php while ($skill = $skills_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($skill['skill_name']); ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No skills listed.</p>
            <?php endif; ?>
            <!-- Education Section -->
<div class="cv-section-title">Education</div>
<?php if ($education_result->num_rows > 0): ?>
    <ul>
        <?php while ($education = $education_result->fetch_assoc()): ?>
            <li>
                <strong><?php echo htmlspecialchars($education['school_name']); ?></strong> - 
                <?php echo htmlspecialchars($education['department']); ?> 
                (<?php echo htmlspecialchars($education['start_date']); ?> to <?php echo htmlspecialchars($education['end_date'] ?: 'Present'); ?>)
                <p><?php echo nl2br(htmlspecialchars($education['description'])); ?></p>
            </li>
        <?php endwhile; ?>
    </ul>
<?php else: ?>
    <p>No education listed.</p>
<?php endif; ?>


            <!-- Experience Section -->
            <div class="cv-section-title">Experience</div>
            <?php if ($experience_result->num_rows > 0): ?>
                <ul>
                    <?php while ($experience = $experience_result->fetch_assoc()): ?>
                        <li><strong><?php echo htmlspecialchars($experience['job_title']); ?></strong> at <?php echo htmlspecialchars($experience['company_name']); ?>
                            (<?php echo htmlspecialchars($experience['start_date']); ?> to <?php echo htmlspecialchars($experience['end_date'] ?: 'Present'); ?>)
                            <p><?php echo nl2br(htmlspecialchars($experience['description'])); ?></p>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No experience listed.</p>
            <?php endif; ?>

            <!-- Tasks Section -->
            <div class="cv-section-title">Tasks</div>
            <?php if ($task_result->num_rows > 0): ?>
                <ul>
                    <?php while ($task = $task_result->fetch_assoc()): ?>
                        <li><?php echo nl2br(htmlspecialchars($task['job_description'])); ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No tasks listed.</p>
            <?php endif; ?>

            <!-- Hobbies Section -->
            <div class="cv-section-title">Hobbies</div>
            <?php if ($hobbies_result->num_rows > 0): ?>
                <ul>
                    <?php while ($hobby = $hobbies_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($hobby['hobby_name']); ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No hobbies listed.</p>
            <?php endif; ?>

            <!-- Languages Section -->
            <div class="cv-section-title">Languages</div>
            <?php if ($languages_result->num_rows > 0): ?>
                <ul>
                    <?php while ($language = $languages_result->fetch_assoc()): ?>
                        <li><?php echo htmlspecialchars($language['language_name']); ?> (<?php echo htmlspecialchars($language['proficiency_level']); ?>)</li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No languages listed.</p>
            <?php endif; ?>

            <!-- Edit and Delete Options -->
            <div class="mt-4">
             <a href="edit_cvs.php?cv_id=<?php echo $cv['id']; ?>" class="btn btn-primary">Edit CV</a>
              <a href="delete_cv.php?cv_id=<?php echo $cv['id']; ?>" class="btn btn-danger">Delete CV</a>
              <a href="generate_pdf.php?cv_id=<?php echo $cv['id']; ?>" class="btn btn-success">Download as PDF</a>

                <a href="javascript:void(0);" onclick="goBack();" class="btn btn-secondary">Go Back</a>
            </div>

            <script>
                function goBack() {
                    // Check if there is a history entry
                    if (window.history.length > 1) {
                        window.history.back();
                    } else {
                        window.location.href = 'create_cv.php'; // Fallback page if no history
                    }
                }
            </script>

        <?php endif; ?>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
