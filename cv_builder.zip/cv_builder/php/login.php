<?php
session_start();
$error = "";

include 'db.php'; // Include database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);  // Trim whitespace from input
    $password = trim($_POST['password']);  // Trim whitespace from input

    // Prepare the statement to check username and password
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows === 1) {  // If exactly one user found
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];  // Store the user ID in the session
            $_SESSION['username'] = $user['username'];  // Store the username in the session
            $_SESSION['role'] = $user['role']; // Store role in session

            // Redirect based on role
            if ($user['role'] == 'admin') {
                header("Location: admin.php");
                exit();  // Ensure no further code is executed after redirect
            } elseif ($user['role'] == 'employer') {
                header("Location: employer.php");  // Redirect to employer page
                exit();  // Ensure no further code is executed after redirect
            } else {
                header("Location: ../index.php");  // Redirect to homepage or other page
                exit();  // Ensure no further code is executed after redirect
            }
        } else {
            $error = "Invalid password."; // If password does not match
        }
    } else {
        // No user found with this username
        $error = "Invalid username.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    <!-- Bootstrap CSS (using the latest version) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Stylesheet -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
            background-color: #f8f9fa;
        }

        .login-form {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #007bff;
        }

        .form-label {
            font-weight: bold;
        }

        .form-control {
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            background-color: #007bff;
            color: white;
            border: none;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 15px;
        }

        .footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 15px;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        .register-link {
            text-align: center;
            margin-top: 15px;
        }

        .register-link a {
            text-decoration: none;
            color: #007bff;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="login-form">
        <h2>Login</h2>
        
        <form method="POST" action="" id="loginForm">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>

            <button type="submit" class="btn">Login</button>

            <!-- Error message display -->
            <?php if (isset($error)) echo "<p class='error-message'>$error</p>"; ?>
        </form>

         <div class="register-link">
             <p><a href="forget_password.php">Forgot your password?</a></p>  <!-- Added Forgot Password link -->
         </div>


        <!-- Register Link -->
        <div class="register-link">
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </div>
    </div>
</div>

<!-- Footer Section -->
<div class="footer">
    <p>&copy; 2024 CV Builder. All rights reserved.</p>
</div>

<!-- Bootstrap JS (Popper.js and Bootstrap JS) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>

<!-- Custom JS for Form Validation -->
<script>
    document.getElementById("loginForm").addEventListener("submit", function(event) {
        let username = document.getElementById("username").value.trim();
        let password = document.getElementById("password").value.trim();

        if (username === "" || password === "") {
            event.preventDefault();
            alert("Both fields are required.");
        }
    });
</script>

</body>
</html>


