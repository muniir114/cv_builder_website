<?php
// Example of hashing a password
$password = 'your_password'; // Replace with your desired password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Output the hashed password
echo $hashed_password; // Use this output in your SQL insert statement
?>
