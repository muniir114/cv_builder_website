<?php 
// Include the PHPMailer class files directly from the 'php/PHPMailer' folder
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';
require_once __DIR__ . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Initialize PHPMailer
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';                               // Set the SMTP server to Gmail
    $mail->SMTPAuth = true;                                       // Enable SMTP authentication
    $mail->Username = 'your-email@gmail.com';                     // SMTP username (your Gmail email)
    $mail->Password = 'your-email-password';                       // SMTP password (your Gmail password)
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;           // Enable TLS encryption
    $mail->Port = 587;                                            // TCP port to connect to (usually 587 for TLS)

    //Recipients
    $mail->setFrom('your-email@gmail.com', 'CV Builder');
    $mail->addAddress('recipient-email@example.com');             // Add a recipient

    // Content
    $mail->isHTML(true);                                          // Set email format to HTML
    $mail->Subject = 'Password Reset Request';
    $mail->Body    = 'Please click the following link to reset your password: <a href="http://localhost/cv_builder/reset_password.php?email=recipient-email@example.com&token=your-token">Reset Password</a>';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
