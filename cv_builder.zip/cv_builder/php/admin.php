<?php
session_start();
include 'db.php'; // Include your database connection file

// Check if the user is logged in as an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php'); // Redirect to login if not logged in as admin
    exit();
}

// Handle Delete User Action
if (isset($_POST['delete_user'])) {
    $user_id = $_POST['user_id'];
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    header('Location: admin.php'); // Redirect back after deletion
    exit();
}

// Handle Delete Application Action (Soft Delete - Mark as Deleted)
// Handle Delete Application Action (Soft Delete - Mark as Deleted)
if (isset($_POST['delete_application'])) {
    $cv_id = $_POST['application_id'];
    $stmt = $conn->prepare("UPDATE cvs SET deleted = 1 WHERE id = ?");
    $stmt->bind_param("i", $cv_id);
    $stmt->execute();
    header('Location: admin.php'); // Redirect back after deletion
    exit();
}


// Handle Restore Application Action
if (isset($_POST['restore_application'])) {
    $cv_id = $_POST['application_id'];
    $stmt = $conn->prepare("UPDATE cvs SET deleted = 0 WHERE id = ?");
    $stmt->bind_param("i", $cv_id);
    $stmt->execute();
    header('Location: admin.php'); // Redirect back after restoration
    exit();
}

// Handle Permanent Delete Action
// Handle Permanent Delete Action
if (isset($_POST['permanent_delete_application'])) {
    $cv_id = $_POST['application_id'];

    // Start a database transaction to delete CV and related data
    $conn->begin_transaction();
    try {
        // Delete related data from the education, skills, etc.
        $tables = ['education', 'skills', 'experience', 'task', 'hobbies', 'languages'];
        foreach ($tables as $table) {
            $stmt = $conn->prepare("DELETE FROM {$table} WHERE cv_id = ?");
            $stmt->bind_param("i", $cv_id);
            if (!$stmt->execute()) {
                throw new Exception("Error deleting {$table} data: " . $stmt->error);
            }
        }

        // Finally, delete the CV itself
        $stmt = $conn->prepare("DELETE FROM cvs WHERE id = ?");
        $stmt->bind_param("i", $cv_id);
        if (!$stmt->execute()) {
            throw new Exception("Error deleting CV: " . $stmt->error);
        }

        // Commit the transaction
        $conn->commit();
        header('Location: admin.php'); // Redirect back after successful deletion
        exit();
    } catch (Exception $e) {
        // Rollback the transaction in case of error
        $conn->rollback();
        echo "Error: " . $e->getMessage();
    }
}


// Pagination and Search Logic for Users and Applications
$limit = 10;  // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start_from = ($page - 1) * $limit;

// Get total number of users
$total_users = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$total_pages_users = ceil($total_users / $limit);

// Get users list
$search_user = '';
if (isset($_GET['search_user'])) {
    $search_user = $_GET['search_user'];
    $search_user = $conn->real_escape_string($search_user);
    $stmt = $conn->prepare("SELECT * FROM users WHERE name LIKE ? OR email LIKE ? LIMIT ?, ?");
    $search_user = "%$search_user%";
    $stmt->bind_param('ssii', $search_user, $search_user, $start_from, $limit);
    $stmt->execute();
    $users = $stmt->get_result();
} else {
    $users = $conn->query("SELECT * FROM users LIMIT $start_from, $limit");
}

// Get total number of applications (CVs)
$total_apps = $conn->query("SELECT COUNT(*) FROM cvs WHERE deleted = 0")->fetch_row()[0]; // Only active (non-deleted) CVs
$total_pages_apps = ceil($total_apps / $limit);

// Get applications list (excluding deleted)
$search_application = '';
if (isset($_GET['search_application'])) {
    $search_application = $_GET['search_application'];
    $search_application = $conn->real_escape_string($search_application);
    $stmt = $conn->prepare("SELECT * FROM cvs WHERE deleted = 0 AND description LIKE ? LIMIT ?, ?");
    $search_application = "%$search_application%";
    $stmt->bind_param('sii', $search_application, $start_from, $limit);
    $stmt->execute();
    $applications = $stmt->get_result();
} else {
    $applications = $conn->query("SELECT * FROM cvs WHERE deleted = 0 LIMIT $start_from, $limit");
}

// Remove the premature closing of the connection
// $conn->close(); // Remove this line to keep the connection open

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center text-primary">Admin Dashboard</h2>

        <!-- User Management Section -->
        <div class="mb-4">
            <h3>User Management</h3>
            
            <!-- Add User Button -->
            <a href="add_user.php" class="btn btn-success mb-3">Add New User</a>

            <form id="userSearchForm" class="d-flex mb-3">
                <input type="text" id="search_user" value="<?php echo htmlspecialchars($search_user); ?>" placeholder="Search users by name or email" class="form-control me-2">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>

            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Number</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $counter = 1; ?>
                    <?php while ($user = $users->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo "User $counter"; ?></td>
                            <td><?php echo htmlspecialchars($user['name']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                    <button type="submit" name="delete_user" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                                <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">Edit</a> |
                                <a href="view_user.php?id=<?php echo $user['id']; ?>" class="btn btn-info btn-sm">View</a>
                            </td>
                        </tr>
                        <?php $counter++; ?>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Application Management Section -->
<!-- Application Management Section -->
<div class="mb-4">
    <h3>Application Management</h3>
    
    <!-- Add Application Button -->
    <a href="Analytics_Dashboard.php" class="btn btn-success mb-3">Analytics Dashboard</a>

    <form id="applicationSearchForm" class="d-flex mb-3">
        <input type="text" id="search_application" value="<?php echo htmlspecialchars($search_application); ?>" placeholder="Search applications by description" class="form-control me-2">
        <button type="submit" class="btn btn-primary">Search</button>
    </form>

    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Number</th> <!-- Added Number column -->
                <th>User Name</th>
                <th>Email</th>
                <th>CV Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                // Initialize an empty array to keep track of CV counts per user
                $user_cv_counts = [];
            ?>
            <?php while ($application = $applications->fetch_assoc()): ?>
                <?php
                    // Fetch user details for the current application
                    $user_id = $application['user_id'];
                    $user_result = $conn->query("SELECT * FROM users WHERE id = $user_id");
                    $user = $user_result->fetch_assoc();
                    
                    // If it's a new user, initialize their CV count
                    if (!isset($user_cv_counts[$user_id])) {
                        $user_cv_counts[$user_id] = 1;
                    } else {
                        // Increment the CV count for the user
                        $user_cv_counts[$user_id]++;
                    }

                    // Get the current CV count for this user
                    $cv_number = $user_cv_counts[$user_id];
                ?>
                <tr>
                    <td><?php echo "CV $cv_number"; ?></td> <!-- Displaying the CV count -->
                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($application['description']); ?></td>
                    <td>
                        <!-- Actions -->
                        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteApplicationModal<?php echo $application['id']; ?>">Delete</button>
                        <a href="edit_application.php?id=<?php echo $application['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="view_application.php?id=<?php echo $application['id']; ?>" class="btn btn-info btn-sm">View</a>
                        <!-- Permanent Delete Action -->
                        <button class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#permanentDeleteApplicationModal<?php echo $application['id']; ?>">Permanent Delete</button>
                    </td>
                </tr>

                <!-- Soft Delete Modal -->
                <div class="modal fade" id="deleteApplicationModal<?php echo $application['id']; ?>" tabindex="-1" aria-labelledby="deleteApplicationModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteApplicationModalLabel">Confirm Soft Delete</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Are you sure you want to mark this CV as deleted? It will be hidden but not permanently deleted.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <form method="POST" action="admin.php">
                                    <input type="hidden" name="application_id" value="<?php echo $application['id']; ?>">
                                    <button type="submit" name="delete_application" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Permanent Delete Modal -->
                <div class="modal fade" id="permanentDeleteApplicationModal<?php echo $application['id']; ?>" tabindex="-1" aria-labelledby="permanentDeleteApplicationModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="permanentDeleteApplicationModalLabel">Confirm Permanent Delete</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                Are you sure you want to permanently delete this CV and all associated data? This action cannot be undone.
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <form method="POST" action="admin.php">
                                    <input type="hidden" name="application_id" value="<?php echo $application['id']; ?>">
                                    <button type="submit" name="permanent_delete_application" class="btn btn-danger">Permanent Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Pagination for Applications -->
    <div class="d-flex justify-content-center">
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <?php for ($i = 1; $i <= $total_pages_apps; $i++): ?>
                    <li class="page-item">
                        <a class="page-link" href="admin.php?page=<?php echo $i; ?>&search_application=<?php echo $search_application; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

