<?php
// index.php

include 'db.php';

// Query to fetch user summary data
$query = "
SELECT
    (SELECT COUNT(*) FROM users) AS total_users,
    (SELECT COUNT(*) FROM users WHERE role = 'admin') AS total_admins,
    (SELECT COUNT(*) FROM users WHERE role = 'employer') AS total_employers,
    (SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()) AS new_users_today
";
$result = $conn->query($query);
$userData = $result->fetch_assoc();

// Query to fetch CV summary data
$query2 = "
SELECT
    (SELECT COUNT(*) FROM cvs) AS total_cvs,
    (SELECT COUNT(*) FROM cvs WHERE deleted = 0) AS active_cvs,
    (SELECT COUNT(*) FROM cvs WHERE deleted = 1) AS deleted_cvs
";
$result2 = $conn->query($query2);
$cvsData = $result2->fetch_assoc();

// Query to fetch skills overview data
$query3 = "
SELECT
    (SELECT COUNT(*) FROM skills) AS total_skills,
    (SELECT AVG(skill_rating) FROM skills) AS avg_skill_rating
";
$result3 = $conn->query($query3);
$skillsData = $result3->fetch_assoc();

// Query to fetch education statistics data
$query4 = "
SELECT
    (SELECT COUNT(*) FROM education) AS total_education_records,
    (SELECT COUNT(DISTINCT school_name) FROM education) AS total_schools,
    (SELECT COUNT(DISTINCT department) FROM education) AS total_departments
";
$result4 = $conn->query($query4);
$educationData = $result4->fetch_assoc();

// Query to fetch experience statistics data
$query5 = "
SELECT
    (SELECT COUNT(*) FROM experience) AS total_experiences,
    (SELECT AVG(DATEDIFF(end_date, start_date)) FROM experience WHERE end_date IS NOT NULL) AS avg_experience_duration
";
$result5 = $conn->query($query5);
$experienceData = $result5->fetch_assoc();

// Query to fetch languages overview data
$query6 = "
SELECT
    (SELECT COUNT(*) FROM languages) AS total_languages,
    (SELECT COUNT(*) FROM languages WHERE proficiency_level = 'Beginner') AS beginner,
    (SELECT COUNT(*) FROM languages WHERE proficiency_level = 'Intermediate') AS intermediate,
    (SELECT COUNT(*) FROM languages WHERE proficiency_level = 'Advanced') AS advanced,
    (SELECT COUNT(*) FROM languages WHERE proficiency_level = 'Fluent') AS fluent
";
$result6 = $conn->query($query6);
$languagesData = $result6->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css"> <!-- Link to the updated stylesheet -->
</head>
    <title>Admin Dashboard</title>
    <style>
        /* Global styles */
        /* Global styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f6f9;
    color: #333;
}

.dashboard-container {
    width: 100%;
    margin: 0 auto;
    padding: 20px;
}

header {
    text-align: center;
    margin-bottom: 40px;
}

h1 {
    font-size: 36px;
    color: #333;
}

.dashboard-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
}

/* Base card style */
.stat-card {
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

/* Hover effect to lift cards */
.stat-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

/* Header of the stat card */
.stat-card h2 {
    font-size: 24px;
    margin-bottom: 15px;
    color: #333;
}

/* List styling */
.stat-card ul {
    list-style: none;
}

.stat-card ul li {
    font-size: 18px;
    color: #555;
    margin-bottom: 10px;
}

.stat-card ul li span {
    font-weight: bold;
}

/* Card colors based on the type of data */
.stat-card.user-summary {
    background-color: #d3e5ff; /* Light Blue */
}

.stat-card.cv-summary {
    background-color: #ffd6d6; /* Light Red */
}

.stat-card.skills-overview {
    background-color: #c6f7c3; /* Light Green */
}

.stat-card.education-overview {
    background-color: #fff4c2; /* Light Yellow */
}

.stat-card.experience-overview {
    background-color: #e0c1f7; /* Light Purple */
}

.stat-card.languages-overview {
    background-color: #e0f7fa; /* Light Cyan */
}

/* Dynamic colors based on the data - use conditional classes or inline styles for more dynamic visual feedback */
.stat-card .highlight {
    color: #2a8e33; /* Dark Green for important numbers */
}

.stat-card .highlight-negative {
    color: #d9534f; /* Red for negative/low numbers */
}

        /* Back Button Styles */
        .btn-back {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 20px;
            background-color: #4CAF50; /* Green */
            color: white;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s, transform 0.3s;
        }

        /* Hover effect */
        .btn-back:hover {
            background-color: #45a049;
            transform: translateY(-5px);
        }
/* Media query for responsive design */
@media (max-width: 768px) {
    .dashboard-stats {
        grid-template-columns: 1fr;
    }
}

    </style>
</head>
<body>
    <div class="dashboard-container">
        <header>
            <h1>Analytics Dashboard</h1>
        </header>
        
        <div class="dashboard-stats">
            <!-- User Summary -->
            <div class="stat-card user-summary">
                <h2>User Summary</h2>
                <ul>
                    <li>Total Users: <span class="highlight"><?= $userData['total_users']; ?></span></li>
                    <li>Admin Users: <?= $userData['total_admins']; ?></li>
                    <li>Employers: <?= $userData['total_employers']; ?></li>
                    <li>New Users Today: <?= $userData['new_users_today']; ?></li>
                </ul>
            </div>

            <!-- CV Summary -->
            <div class="stat-card cv-summary">
                <h2>CV Summary</h2>
                <ul>
                    <li>Total CVs: <?= $cvsData['total_cvs']; ?></li>
                    <li>Active CVs: <span class="highlight"><?= $cvsData['active_cvs']; ?></span></li>
                    <li>Deleted CVs: <?= $cvsData['deleted_cvs']; ?></li>
                </ul>
            </div>

            <!-- Skills Overview -->
            <div class="stat-card skills-overview">
                <h2>Skills Overview</h2>
                <ul>
                    <li>Total Skills: <?= $skillsData['total_skills']; ?></li>
                    <li>Average Skill Rating: <?= round($skillsData['avg_skill_rating'], 2); ?></li>
                </ul>
            </div>

            <!-- Education Overview -->
            <div class="stat-card education-overview">
                <h2>Education Overview</h2>
                <ul>
                    <li>Total Education Records: <?= $educationData['total_education_records']; ?></li>
                    <li>Schools: <?= $educationData['total_schools']; ?></li>
                    <li>Departments: <?= $educationData['total_departments']; ?></li>
                </ul>
            </div>

            <!-- Experience Overview -->
            <div class="stat-card experience-overview">
                <h2>Experience Overview</h2>
                <ul>
                    <li>Total Experiences: <?= $experienceData['total_experiences']; ?></li>
                    <li>Average Experience Duration: <span class="highlight"><?= round($experienceData['avg_experience_duration'], 2); ?> days</span></li>
                </ul>
            </div>

            <!-- Languages Overview -->
            <div class="stat-card languages-overview">
                <h2>Languages Overview</h2>
                <ul>
                    <li>Total Languages: <?= $languagesData['total_languages']; ?></li>
                    <li>Beginner: <?= $languagesData['beginner']; ?></li>
                    <li>Intermediate: <?= $languagesData['intermediate']; ?></li>
                    <li>Advanced: <?= $languagesData['advanced']; ?></li>
                    <li>Fluent: <?= $languagesData['fluent']; ?></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Back Button -->
    <a href="admin.php" class="btn btn-secondary btn-back">Back to Admin Dashboard</a>
</body>
</html>