<?php
ob_start();  // Start output buffering

include('db.php');
require('fpdf/fpdf.php');  // Ensure you have FPDF or another PDF library included

// Ensure the cv_id is provided
if (!isset($_GET['cv_id'])) {
    echo "CV ID not provided in the URL.";
    exit();
}

$cv_id = $_GET['cv_id'];  // Get the cv_id from the URL

// Fetch the CV data from the database, ensuring that the CV is not marked as deleted
$stmt = $conn->prepare("SELECT * FROM cvs WHERE id = ? AND deleted = 0");
$stmt->bind_param("i", $cv_id);
$stmt->execute();
$cv_result = $stmt->get_result();

if ($cv_result->num_rows == 0) {
    echo "CV not found or it has been deleted.";
    exit();
}

$cv = $cv_result->fetch_assoc();

// Fetch user information using user_id from cvs table
$user_stmt = $conn->prepare("SELECT name, email, phone_number, address FROM users WHERE id = ?");
$user_stmt->bind_param("i", $cv['user_id']);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Check if we should ask the user to download the PDF
$ask_download = isset($_GET['ask_download']) && $_GET['ask_download'] == 'true';

if ($ask_download) {
    // Display the "Download as PDF" button
    echo '<div class="container">';
    echo '<h2>Do you want to download your CV as a PDF?</h2>';
    echo '<a href="generate_pdf.php?cv_id=' . $cv_id . '" class="btn btn-success">Download as PDF</a>';
    echo '</div>';
} else {
    // If not asking for download, generate and automatically download the PDF
    generate_pdf($cv, $user, $conn);
}

function generate_pdf($cv, $user, $conn) {
    // Create the PDF
    $pdf = new FPDF();
    $pdf->AddPage();

    // Set font for the resume
    $pdf->SetFont('Arial', '', 12);

    // Add profile picture if available (Place it at the top of the page)
    if (!empty($cv['profile_picture'])) {
        $profile_picture_path = 'uploads/profile_pictures/' . $cv['profile_picture'];
        if (file_exists($profile_picture_path)) {
            // Adjust position and size as needed
            $pdf->Image($profile_picture_path, 10, 10, 30);  // X=10, Y=10, Width=30
        }
    }

    // Move below the image
    $pdf->Ln(40);  // 40 units down from the top (or adjust this value as necessary)

    // Add CV title (optional)
    $pdf->SetFont('Arial', 'B', 17);
    $pdf->Cell(0, 10, 'cv builder', 0, 1, 'C');  // Centered title
    $pdf->Ln(10);  // Line break for spacing

    // User Information (Name, Email, Phone, Address)
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Contact Information', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Name: ' . $user['name'], 0, 1);
    $pdf->Cell(0, 10, 'Email: ' . $user['email'], 0, 1);
    $pdf->Cell(0, 10, 'Phone: ' . $user['phone_number'], 0, 1);
    $pdf->Cell(0, 10, 'Address: ' . $user['address'], 0, 1);
     // Add space between sections

 // CV Description
    $pdf->Cell(0, 10, 'Description: ' . $cv['description'], 0, 1);
    $pdf->Ln(10); 
    
    // --- Education Section ---
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Education', 0, 1);
    $pdf->SetFont('Arial', '', 12);

    $edu_stmt = $conn->prepare("SELECT * FROM education WHERE cv_id = ? AND cv_id IN (SELECT id FROM cvs WHERE deleted = 0)");
    $edu_stmt->bind_param("i", $cv['id']);
    $edu_stmt->execute();
    $edu_result = $edu_stmt->get_result();

    if ($edu_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No education records available.', 0, 1);
    } else {
        while ($edu = $edu_result->fetch_assoc()) {
            $pdf->Cell(0, 10, $edu['school_name'] . ' (' . $edu['start_date'] . ' - ' . $edu['end_date'] . ')', 0, 1);
            $pdf->MultiCell(0, 10, 'Description: ' . $edu['description']);
            $pdf->Ln(5);  // Add some space between each education record
        }
    }

    // --- Skills Section ---
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Skills', 0, 1);
    $pdf->SetFont('Arial', '', 12);

    $skills_stmt = $conn->prepare("SELECT * FROM skillss WHERE cv_id = ? AND cv_id IN (SELECT id FROM cvs WHERE deleted = 0)");
    $skills_stmt->bind_param("i", $cv['id']);
    $skills_stmt->execute();
    $skills_result = $skills_stmt->get_result();

    if ($skills_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No skills records available.', 0, 1);
    } else {
        while ($skill = $skills_result->fetch_assoc()) {
            $pdf->Cell(0, 10, $skill['skill_name'], 0, 1);
        }
    }

    // --- Languages Section ---
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Languages', 0, 1);
    $pdf->SetFont('Arial', '', 12);

    $languages_stmt = $conn->prepare("SELECT * FROM languages WHERE cv_id = ? AND cv_id IN (SELECT id FROM cvs WHERE deleted = 0)");
    $languages_stmt->bind_param("i", $cv['id']);
    $languages_stmt->execute();
    $languages_result = $languages_stmt->get_result();

    if ($languages_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No languages records available.', 0, 1);
    } else {
        while ($language = $languages_result->fetch_assoc()) {
            $pdf->Cell(0, 10, $language['language_name'] . ' (' . $language['proficiency_level'] . ')', 0, 1);
        }
    }

    // --- Experience Section ---
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Experience', 0, 1);
    $pdf->SetFont('Arial', '', 12);

    $exp_stmt = $conn->prepare("SELECT * FROM experience WHERE cv_id = ? AND cv_id IN (SELECT id FROM cvs WHERE deleted = 0)");
    $exp_stmt->bind_param("i", $cv['id']);
    $exp_stmt->execute();
    $exp_result = $exp_stmt->get_result();

    if ($exp_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No experience records available.', 0, 1);
    } else {
        while ($exp = $exp_result->fetch_assoc()) {
            $pdf->Cell(0, 10, $exp['job_title'] . ' at ' . $exp['company_name'] . ' (' . $exp['start_date'] . ' - ' . $exp['end_date'] . ')', 0, 1);
            $pdf->MultiCell(0, 10, 'Description: ' . $exp['description']);
        }
    }

    // --- Task Section ---
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Tasks', 0, 1);
    $pdf->SetFont('Arial', '', 12);

    $tasks_stmt = $conn->prepare("SELECT * FROM task WHERE cv_id = ? AND cv_id IN (SELECT id FROM cvs WHERE deleted = 0)");
    $tasks_stmt->bind_param("i", $cv['id']);
    $tasks_stmt->execute();
    $tasks_result = $tasks_stmt->get_result();

    if ($tasks_result->num_rows == 0) {
        $pdf->Cell(0, 10, 'No tasks records available.', 0, 1);
    } else {
        while ($task = $tasks_result->fetch_assoc()) {
            $pdf->MultiCell(0, 10, 'Job Description: ' . $task['job_description']);
        }
    }

    // Output the PDF to the browser
    $pdf->Output('D', 'CV_' . $cv['id'] . '.pdf');
}
?>




