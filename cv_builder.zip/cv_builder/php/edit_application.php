<?php
session_start();
include 'db.php';

// Ensure the user is logged in (admin role check can go here)
if (isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Get application ID (cv_id) from URL
if (isset($_GET['id'])) {
    $cv_id = $_GET['id'];

    // Fetch user and CV data from the database
    $stmt = $conn->prepare("SELECT 
                                users.id AS user_id, 
                                users.name, 
                                users.email, 
                                users.phone_number, 
                                users.address, 
                                cvs.profile_picture,
                                cvs.id AS cv_id, 
                                cvs.description
                            FROM users
                            LEFT JOIN cvs ON users.id = cvs.user_id
                            WHERE cvs.id = ?");
    $stmt->bind_param('i', $cv_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $application = $result->fetch_assoc();
    } else {
        $error_message = "No application data found for this ID";
    }

    // Fetch data for Education, Skills, Experience, etc.
    $education_result = $conn->query("SELECT * FROM education WHERE cv_id = $cv_id");
    $skills_result = $conn->query("SELECT * FROM skillss WHERE cv_id = $cv_id");
    $experience_result = $conn->query("SELECT * FROM experience WHERE cv_id = $cv_id");
    $hobbies_result = $conn->query("SELECT * FROM hobbies WHERE cv_id = $cv_id");
    $languages_result = $conn->query("SELECT * FROM languages WHERE cv_id = $cv_id");
    $task_result = $conn->query("SELECT * FROM task WHERE cv_id = $cv_id");

    // Handle form submission for updating the application
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
        $address = $_POST['address'];
        $description = $_POST['description'];

        // Update user and CV information in the database
        $update_user_stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, phone_number = ?, address = ? WHERE id = ?");
        $update_user_stmt->bind_param('ssssi', $name, $email, $phone_number, $address, $application['user_id']);
        $update_user_stmt->execute();

        $update_cv_stmt = $conn->prepare("UPDATE cvs SET description = ? WHERE id = ?");
        $update_cv_stmt->bind_param('si', $description, $cv_id);
        $update_cv_stmt->execute();

        // Update Education
        if (isset($_POST['education'])) {
            foreach ($_POST['education'] as $education_id => $education_data) {
                $school_name = $education_data['school_name'];
                $start_date = $education_data['start_date'];
                $end_date = $education_data['end_date'];
                $department = $education_data['department'];
                $edu_description = $education_data['description'];

                $update_education_stmt = $conn->prepare("UPDATE education SET school_name = ?, start_date = ?, end_date = ?, department = ?, description = ? WHERE education_id = ?");
                $update_education_stmt->bind_param('sssssi', $school_name, $start_date, $end_date, $department, $edu_description, $education_id);
                $update_education_stmt->execute();
            }
        }

        // Update Skills
        if (isset($_POST['skillss'])) {
            foreach ($_POST['skills'] as $skill_id => $skill_name) {
                

                $update_skills_stmt = $conn->prepare("UPDATE skillss SET skill_name = ?, skill_rating = ? WHERE id = ?");
                $update_skills_stmt->execute();
            }
        }

        // Update Experience
        if (isset($_POST['experience'])) {
            foreach ($_POST['experience'] as $exp_id => $exp_data) {
                $job_title = $exp_data['job_title'];
                $company_name = $exp_data['company_name'];
                $start_date = $exp_data['start_date'];
                $end_date = $exp_data['end_date'];
                $exp_description = $exp_data['description'];

                $update_experience_stmt = $conn->prepare("UPDATE experience SET job_title = ?, company_name = ?, start_date = ?, end_date = ?, description = ? WHERE experience_id = ?");
                $update_experience_stmt->bind_param('sssssi', $job_title, $company_name, $start_date, $end_date, $exp_description, $exp_id);
                $update_experience_stmt->execute();
            }
        }

        // Update Hobbies
        if (isset($_POST['hobbies'])) {
            foreach ($_POST['hobbies'] as $hobby_id => $hobby_name) {
                $update_hobbies_stmt = $conn->prepare("UPDATE hobbies SET hobby_name = ? WHERE id = ?");
                $update_hobbies_stmt->bind_param('si', $hobby_name, $hobby_id);
                $update_hobbies_stmt->execute();
            }
        }

        // Update Languages
        if (isset($_POST['languages'])) {
            foreach ($_POST['languages'] as $language_id => $language_data) {
                $language_name = $language_data['language_name'];
                $proficiency_level = $language_data['proficiency_level'];

                $update_languages_stmt = $conn->prepare("UPDATE languages SET language_name = ?, proficiency_level = ? WHERE id = ?");
                $update_languages_stmt->bind_param('ssi', $language_name, $proficiency_level, $language_id);
                $update_languages_stmt->execute();
            }
        }

        // Update Task
        if (isset($_POST['task'])) {
            foreach ($_POST['task'] as $task_id => $task_data) {
                $job_description = $task_data['job_description'];

                $update_task_stmt = $conn->prepare("UPDATE task SET job_description = ? WHERE task_id = ?");
                $update_task_stmt->bind_param('si', $job_description, $task_id);
                $update_task_stmt->execute();
            }
        }

        // Redirect to a success page or back to the admin dashboard
        header("Location: admin.php?success=1");
        exit();
    }
} else {
    $error_message = "No application ID provided!";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Application</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
            margin-top: 50px;
        }
        .application-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }


        .btn-back {
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center text-primary mb-4">Edit Application Details</h2>

    <!-- Error Message (if application not found) -->
    <?php if (isset($error_message)): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>

    <!-- Edit Form -->
    <?php if (isset($application)): ?>
        <form action="edit_application.php?id=<?php echo $cv_id; ?>" method="POST" enctype="multipart/form-data">
            <!-- Profile Picture -->
<!-- Profile Picture -->
<div class="text-center">
    <?php if (!empty($application['profile_picture'])): ?>
        <img src="uploads/profile_pictures/<?php echo htmlspecialchars($application['profile_picture']); ?>" alt="Profile Picture" style="width: 200px; height: 200px;">
    <?php else: ?>
        <img src="https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-High-Quality-Image.png" alt="Default image" style="width: 200px; height: 200px;">
    <?php endif; ?>
</div>
            <!-- User Details -->
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($application['name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($application['email']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="phone_number" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($application['phone_number']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($application['address']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">CV Description</label>
                <textarea class="form-control" id="description" name="description" rows="4" required><?php echo htmlspecialchars($application['description']); ?></textarea>
            </div>

            <!-- Education Section -->
            <h4>Education</h4>
            <?php while ($edu = $education_result->fetch_assoc()): ?>
                <div class="mb-3">
                    <input type="text" name="education[<?php echo $edu['education_id']; ?>][school_name]" value="<?php echo htmlspecialchars($edu['school_name']); ?>" class="form-control" placeholder="School Name" required>
                    <input type="date" name="education[<?php echo $edu['education_id']; ?>][start_date]" value="<?php echo $edu['start_date']; ?>" class="form-control" required>
                    <input type="date" name="education[<?php echo $edu['education_id']; ?>][end_date]" value="<?php echo $edu['end_date']; ?>" class="form-control">
                    <input type="text" name="education[<?php echo $edu['education_id']; ?>][department]" value="<?php echo htmlspecialchars($edu['department']); ?>" class="form-control" placeholder="Department">
                    <textarea name="education[<?php echo $edu['education_id']; ?>][description]" class="form-control" placeholder="Description"><?php echo htmlspecialchars($edu['description']); ?></textarea>
                </div>
            <?php endwhile; ?>

            <!-- Skills Section -->
            <h4>Skills</h4>
            <?php while ($skill = $skills_result->fetch_assoc()): ?>
                <div class="mb-3">
                    <input type="text" name="skills[<?php echo $skill['id']; ?>]" value="<?php echo htmlspecialchars($skill['skill_name']); ?>" class="form-control" placeholder="Skill Name" required>
                    
                </div>
            <?php endwhile; ?>

            <!-- Experience Section -->
            <h4>Experience</h4>
            <?php while ($exp = $experience_result->fetch_assoc()): ?>
                <div class="mb-3">
                    <input type="text" name="experience[<?php echo $exp['experience_id']; ?>][job_title]" value="<?php echo htmlspecialchars($exp['job_title']); ?>" class="form-control" placeholder="Job Title" required>
                    <input type="text" name="experience[<?php echo $exp['experience_id']; ?>][company_name]" value="<?php echo htmlspecialchars($exp['company_name']); ?>" class="form-control" placeholder="Company Name" required>
                    <input type="date" name="experience[<?php echo $exp['experience_id']; ?>][start_date]" value="<?php echo $exp['start_date']; ?>" class="form-control" required>
                    <input type="date" name="experience[<?php echo $exp['experience_id']; ?>][end_date]" value="<?php echo $exp['end_date']; ?>" class="form-control">
                    <textarea name="experience[<?php echo $exp['experience_id']; ?>][description]" class="form-control" placeholder="Job Description"><?php echo htmlspecialchars($exp['description']); ?></textarea>
                </div>
            <?php endwhile; ?>

            <!-- Hobbies Section -->
            <h4>Hobbies</h4>
            <?php while ($hobby = $hobbies_result->fetch_assoc()): ?>
                <div class="mb-3">
                    <input type="text" name="hobbies[<?php echo $hobby['id']; ?>]" value="<?php echo htmlspecialchars($hobby['hobby_name']); ?>" class="form-control" placeholder="Hobby" required>
                </div>
            <?php endwhile; ?>

            <!-- Languages Section -->
            <h4>Languages</h4>
            <?php while ($language = $languages_result->fetch_assoc()): ?>
                <div class="mb-3">
                    <input type="text" name="languages[<?php echo $language['id']; ?>][language_name]" value="<?php echo htmlspecialchars($language['language_name']); ?>" class="form-control" placeholder="Language" required>
                    <select name="languages[<?php echo $language['id']; ?>][proficiency_level]" class="form-control">
                        <option value="Beginner" <?php echo ($language['proficiency_level'] == 'Beginner') ? 'selected' : ''; ?>>Beginner</option>
                        <option value="Intermediate" <?php echo ($language['proficiency_level'] == 'Intermediate') ? 'selected' : ''; ?>>Intermediate</option>
                        <option value="Advanced" <?php echo ($language['proficiency_level'] == 'Advanced') ? 'selected' : ''; ?>>Advanced</option>
                        <option value="Fluent" <?php echo ($language['proficiency_level'] == 'Fluent') ? 'selected' : ''; ?>>Fluent</option>
                    </select>
                </div>
            <?php endwhile; ?>

            <!-- Task Section -->
            <h4>Task</h4>
            <?php while ($task = $task_result->fetch_assoc()): ?>
                <div class="mb-3">
                    <textarea name="task[<?php echo $task['task_id']; ?>][job_description]" class="form-control" placeholder="Task Description"><?php echo htmlspecialchars($task['job_description']); ?></textarea>
                </div>
            <?php endwhile; ?>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary">Update Application</button>
        </form>
    <?php endif; ?>

    <!-- Back to Admin Dashboard -->
    <a href="admin.php" class="btn btn-secondary btn-back">Back to Admin Dashboard</a>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
