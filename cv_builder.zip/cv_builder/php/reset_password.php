<?php
include("db.php"); // Include the database connection (using $conn)

$message = ""; // Initialize message variable

// Check if email and token are passed in the URL
if (isset($_GET['email']) && isset($_GET['token'])) {
    $email = mysqli_real_escape_string($conn, $_GET['email']);  // Use $conn here
    $token = mysqli_real_escape_string($conn, $_GET['token']);  // Use $conn here

    // Verify the token and email in the database
    $query = mysqli_query($conn, "SELECT id, email, reset_token, token_expiry FROM users WHERE email='$email' AND reset_token='$token'");

    // Check if the query returns a result
    if (mysqli_num_rows($query) == 1) {
        $user = mysqli_fetch_assoc($query);
        $token_expiry = $user['token_expiry'];

        // Check if the token has expired
        if (strtotime($token_expiry) < time()) {
            $message = "The reset link has expired. Please request a new one.";
        } else {
            // Token is valid, proceed to password reset
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $new_password = mysqli_real_escape_string($conn, $_POST['password']);
                $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

                if ($new_password === $confirm_password) {
                    // Hash the new password
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

                    // Update the password in the database and clear the reset token
                    $update_sql = "UPDATE users SET password='$hashed_password', reset_token=NULL, token_expiry=NULL WHERE email='$email'";
                    if (mysqli_query($conn, $update_sql)) {
                        $message = "Your password has been successfully updated.";
                    } else {
                        $message = "Failed to update the password. Please try again.";
                    }
                } else {
                    $message = "The passwords do not match. Please try again.";
                }
            }
        }
    } else {
        $message = "Invalid or expired reset link.";
    }
} else {
    $message = "Invalid request.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        input {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input:focus {
            border-color: #4e9f3d;
            outline: none;
        }

        button {
            padding: 10px;
            background-color: #4e9f3d;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .message {
            font-size: 16px;
            color: #e74c3c;
            text-align: center;
            margin-bottom: 20px;
        }

        .success {
            color: #2ecc71;
        }

        .link {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: #4e9f3d;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Your Password</h2>
        <?php if ($message != "") { ?>
            <p class="message <?php echo (strpos($message, 'success') !== false) ? 'success' : ''; ?>"><?php echo $message; ?></p>
        <?php } ?>

        <?php if (isset($_GET['email']) && isset($_GET['token']) && $message == "") { ?>
            <form method="POST">
                <label for="password">New Password:</label>
                <input type="password" name="password" id="password" required><br>

                <label for="confirm_password">Confirm Password:</label>
                <input type="password" name="confirm_password" id="confirm_password" required><br>

                <button type="submit">Update Password</button>
            </form>
        <?php } ?>

        <div class="link">
            <a href="login.php">Back to Login</a>
        </div>
    </div>
</body>
</html>

