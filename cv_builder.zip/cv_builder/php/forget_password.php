<?php
include("db.php"); // Include the database connection

// Manually include the PHPMailer classes
require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/src/SMTP.php';
require_once __DIR__ . '/PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = ""; // Initialize message variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_reg = mysqli_real_escape_string($conn, $_POST['email']); // Use $conn for database connection
    
    // Check if the email exists in the users table
    $details = mysqli_query($conn, "SELECT id, email FROM users WHERE email='$email_reg'");
    
    if (mysqli_num_rows($details) > 0) {
        // Email exists, generate reset token
        $reset_token = bin2hex(random_bytes(16));  // Secure random token
        $token_expiry = date("Y-m-d H:i:s", strtotime('+1 hour'));  // Token expires in 1 hour

        // Update the user record with the reset token and expiry
        $sql_update = "UPDATE users SET reset_token='$reset_token', token_expiry='$token_expiry' WHERE email='$email_reg'";
        
        if (mysqli_query($conn, $sql_update)) {
            // Generate the reset link
            echo("http://localhost/cv_builder/php/reset_password.php?email=$email_reg&token=$reset_token");
            $reset_link = "http://localhost/cv_builder/php/reset_password.php?email=$email_reg&token=$reset_token";
            
            // Send the reset email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'your-email@gmail.com'; // Your Gmail email
                $mail->Password = 'your-email-password'; // Your Gmail password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Recipients
                $mail->setFrom('your-email@gmail.com', 'CV Builder');
                $mail->addAddress($email_reg);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset Request';
                $mail->Body = "Please click the following link to reset your password: <a href='$reset_link'>$reset_link</a>";

                // Send the email
                $mail->send();
                $message = "Please check your email inbox or spam folder for the reset link.";
            } catch (Exception $e) {
                $message = "There was an error sending the email: {$mail->ErrorInfo}";
            }
        } else {
            $message = "Failed to update reset token in the database.";
        }
    } else {
        $message = "Sorry! No account associated with this email.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            max-width: 400px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        input[type="email"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        p {
            color: #e74c3c;
            text-align: center;
            font-size: 16px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Reset Your Password</h2>

        <?php if ($message != "") { echo "<p>$message</p>"; } ?>

        <form method="POST">
            <input type="email" name="email" placeholder="Enter your email" required>
            <button type="submit">Send Reset Link</button>
        </form>
    </div>

</body>
</html>
