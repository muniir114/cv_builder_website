<?php
include 'db.php';  // Include your database connection

// Start session
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // The ID of the logged-in user

// Initialize variables
$search_results = [];
$search_message = "";
$search_term = ''; // Default to empty string

// Query to get all results initially (for displaying all cards)
$sql = "
SELECT 
    users.id AS user_id, 
    users.name, 
    users.email, 
    IFNULL(GROUP_CONCAT(DISTINCT skillss.skill_name), 'No skills listed') AS skill_name, 
    IFNULL(education.school_name, 'No school listed') AS school_name, 
    IFNULL(education.description, 'No description available') AS education_description, 
    cvs.id AS cv_id,
    cvs.profile_picture
FROM users
LEFT JOIN cvs ON users.id = cvs.user_id AND cvs.deleted = 0  -- Ensure the CV is not deleted
LEFT JOIN skillss ON cvs.id = skillss.cv_id  -- Correct join for skills
LEFT JOIN education ON cvs.id = education.cv_id  -- Correct join for education
WHERE cvs.id IS NOT NULL  -- Only include users with an existing CV
GROUP BY users.id, cvs.id
";


// Execute the query
$search_results = $conn->query($sql);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Search - CVs</title>

    <!-- Bootstrap 4 CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-color: #f8f9fa;
    }
    .card-body {
        background-color:#d8edff;
    }
    .card-link {
        text-decoration: none;
        color: inherit;
    }
    .card-link:hover {
        text-decoration: none;
    }
    .card {
        cursor: pointer;
        transition: transform 0.3s, box-shadow 0.3s; /* Smooth transition for hover effects */
    }
    .card:hover {
        transform: scale(1.05); /* Scale the card when hovered */
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2); /* Add a shadow to make it pop */
        color: #000000
    }
    .card-img-top {
        width: 100%;              /* Keep the image at full width of the card */
        height: auto;             /* Let the height be determined by the aspect ratio */
        max-height: 200px;        /* Maximum height of the image */
        object-fit: contain;      /* Ensure the entire image is visible without being cropped */
        object-position: center;  /* Keep the image centered */
        border-bottom: 1px solid #ddd; /* Optional: Add a border below the image */
    }
    .search-form {
        margin-bottom: 20px;
        display: flex;
        align-items: center;
    }
    .search-form input {
        flex-grow: 1;
    }
    .cv-card-title {
        color: #0006ff;
    }
    .pagination {
        justify-content: center;
    }
    .logout-link {
        font-size: 18px;
        margin-left: 10px; /* Small space between search bar and log out link */
    }
    </style>
</head>
<body>
<div class="container my-5">
    <h2 class="text-center text-primary">Employer CV Search</h2>

    <!-- Search Form with Log Out link -->
    <div class="search-form mb-4">
        <input type="text" id="searchInput" class="form-control me-2" placeholder="Search by name, email, skills, or education">
        <!-- Log Out Link -->
        <a href="logout.php" class="logout-link text-primary">Log Out</a>
    </div>

    <!-- Search Results Cards -->
    <h3>Search Results</h3>
    <div id="resultsContainer" class="row">
        <?php if ($search_results->num_rows > 0): ?>
            <?php while ($result = $search_results->fetch_assoc()): ?>
                <div class="col-md-4 mb-4 card-container">
                    <a href="view_cv.php?cv_id=<?php echo $result['cv_id']; ?>" class="card-link">
                        <div class="card shadow-sm">
                            <!-- Card Image -->
                            <?php if (!empty($result['profile_picture'])): ?>
                                <img src="uploads/profile_pictures/<?php echo htmlspecialchars($result['profile_picture']); ?>" class="card-img-top" alt="User image">
                            <?php else: ?>
                                <img src="https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-High-Quality-Image.png" class="card-img-top" alt="Default image">
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <h5 class="card-title cv-card-title"><?php echo htmlspecialchars($result['name']); ?></h5>
                                <p class="card-text"><strong>Email:</strong> <?php echo htmlspecialchars($result['email']); ?></p>
                                <p class="card-text"><strong>School:</strong> <?php echo htmlspecialchars($result['school_name']); ?></p>
                                <p class="card-text"><strong>Skills:</strong> <?php echo htmlspecialchars($result['skill_name']); ?></p>
                                <p class="card-text"><strong>Education Description:</strong> <?php echo htmlspecialchars($result['education_description']); ?></p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning" role="alert">
                    No results found.
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- JavaScript to filter cards -->
<script>
    document.getElementById('searchInput').addEventListener('input', function() {
        let searchValue = this.value.toLowerCase();
        let cards = document.querySelectorAll('.card-container');

        cards.forEach(card => {
            let name = card.querySelector('.card-title').textContent.toLowerCase();
            let email = card.querySelector('.card-text:nth-child(2)').textContent.toLowerCase();
            let school = card.querySelector('.card-text:nth-child(3)').textContent.toLowerCase();
            let skills = card.querySelector('.card-text:nth-child(4)').textContent.toLowerCase();
            
            if (name.includes(searchValue) || email.includes(searchValue) || school.includes(searchValue) || skills.includes(searchValue)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
</script>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
