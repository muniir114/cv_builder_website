<?php
include 'db.php';  // Include your database connection

// Start session
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if 'cv_id' is provided in the URL
if (isset($_GET['cv_id'])) {
    $cv_id = $_GET['cv_id'];

    // SQL query to fetch CV details including personal information, education, experience, skills, tasks, and languages
    $sql = "
    SELECT 
        users.id AS user_id, 
        users.name, 
        users.email, 
        users.phone_number, 
        users.address,
        cvs.profile_picture, 
        cvs.description AS cv_description,
        IFNULL(GROUP_CONCAT(DISTINCT skillss.skill_name), 'No skills listed') AS skill_name, 
        IFNULL(education.school_name, 'No school listed') AS school_name, 
        IFNULL(education.start_date, '') AS education_start_date, 
        IFNULL(education.end_date, '') AS education_end_date, 
        IFNULL(education.description, 'No description available') AS education_description,
        IFNULL(GROUP_CONCAT(DISTINCT experience.job_title), 'No experience listed') AS job_titles,
        IFNULL(GROUP_CONCAT(DISTINCT experience.company_name), 'No experience listed') AS company_names,
        IFNULL(GROUP_CONCAT(DISTINCT experience.start_date), 'No start date listed') AS experience_start_date,
        IFNULL(GROUP_CONCAT(DISTINCT experience.end_date), 'No end date listed') AS experience_end_date,
        IFNULL(GROUP_CONCAT(DISTINCT experience.description), 'No experience description') AS experience_description,
        IFNULL(GROUP_CONCAT(DISTINCT task.job_description), 'No tasks listed') AS tasks,
        IFNULL(GROUP_CONCAT(DISTINCT hobbies.hobby_name), 'No hobbies listed') AS hobbies,
        IFNULL(GROUP_CONCAT(DISTINCT languages.language_name), 'No languages listed') AS languages,
        IFNULL(GROUP_CONCAT(DISTINCT languages.proficiency_level), 'No proficiency levels listed') AS language_levels
    FROM users
    LEFT JOIN cvs ON users.id = cvs.user_id AND cvs.id = ? 
    LEFT JOIN skillss ON cvs.id = skillss.cv_id
    LEFT JOIN education ON cvs.id = education.cv_id
    LEFT JOIN experience ON cvs.id = experience.cv_id
    LEFT JOIN task ON cvs.id = task.cv_id
    LEFT JOIN hobbies ON cvs.id = hobbies.cv_id
    LEFT JOIN languages ON cvs.id = languages.cv_id
    WHERE cvs.deleted = 0
    GROUP BY users.id, cvs.id
    ";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);
    
    if ($stmt === false) {
        die('MySQL prepare error: ' . $conn->error);
    }

    // Bind the cv_id parameter
    $stmt->bind_param("i", $cv_id);

    // Execute the query
    if (!$stmt->execute()) {
        die('Error executing query: ' . $stmt->error);
    }

    // Get the result
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $cv_details = $result->fetch_assoc();  // Store the CV details
    } else {
        die('No CV found.');
    }

    $stmt->close();  // Close the prepared statement
} else {
    die('Invalid request.');
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View CV - <?php echo htmlspecialchars($cv_details['name']); ?></title>

    <!-- Bootstrap 4 CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
      body {
            background-color: #E7DDFF;
        }
        .card-img-top {
            width: 100%;
            height: auto;
            max-height: 300px;
            object-fit: contain;
        }
        .cv-details {
            background-color: #AEE19B;
            padding: 30px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .cv-section {
            margin-bottom: 20px;
        }
        .cv-section h6 {
            font-size: 1.2rem;
            color: #333;
            margin-bottom: 10px;
        }
        .cv-section p {
            font-size: 1rem;
            color: #555;
        }
        .cv-header {
            background-color: #007bff;
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
        }
        .cv-header h2 {
            margin: 0;
        }
        .cv-footer {
            font-size: 0.9rem;
            color: #888;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
            border-top: 1px solid #ddd;
            position: relative;
        }
        .cv-footer a {
            color: #007bff;
            text-decoration: none;
        }
        .cv-footer a:hover {
            text-decoration: underline;
        }
        .back-button {
            position: absolute;
            left: 15px;
            bottom: 10px;
        }
    
        ul {
            list-style-type: none;
            padding-left: 0;
        }
        ul li {
            margin: 5px 0;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <div class="card cv-details">
        <div class="card-header cv-header">
            <h2><?php echo htmlspecialchars($cv_details['name']); ?>'s CV</h2>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Profile Picture -->
                <div class="col-md-4">
                    <?php if (!empty($cv_details['profile_picture'])): ?>
                        <img src="uploads/profile_pictures/<?php echo htmlspecialchars($cv_details['profile_picture']); ?>" class="card-img-top" alt="User image">
                    <?php else: ?>
                        <img src="https://www.pngall.com/wp-content/uploads/5/User-Profile-PNG-High-Quality-Image.png" class="card-img-top" alt="Default image">
                    <?php endif; ?>
                </div>
                <!-- CV Information -->
                <div class="col-md-8">
                    <div class="cv-section">
                        <h6><strong>Email:</strong></h6>
                        <p><?php echo htmlspecialchars($cv_details['email']); ?></p>

                        <h6><strong>Phone Number:</strong></h6>
                        <p><?php echo htmlspecialchars($cv_details['phone_number']); ?></p>

                        <h6><strong>Address:</strong></h6>
                        <p><?php echo htmlspecialchars($cv_details['address']); ?></p>

                        <h6><strong>CV Description:</strong></h6>
                        <p><?php echo htmlspecialchars($cv_details['cv_description']); ?></p>

                        <h6><strong>School:</strong></h6>
                        <p><?php echo htmlspecialchars($cv_details['school_name']); ?></p>
                        <p><strong>Start Date:</strong> <?php echo htmlspecialchars($cv_details['education_start_date']); ?></p>
                        <p><strong>End Date:</strong> <?php echo htmlspecialchars($cv_details['education_end_date']); ?></p>
                        <p><strong>Description:</strong> <?php echo htmlspecialchars($cv_details['education_description']); ?></p>
                    </div>

                    <div class="cv-section">
                        <h6><strong>Experience:</strong></h6>
                        <ul>
                            <?php
                                // Experience data
                                $job_titles = explode(',', $cv_details['job_titles']);
                                $company_names = explode(',', $cv_details['company_names']);
                                $experience_start_dates = explode(',', $cv_details['experience_start_date']);
                                $experience_end_dates = explode(',', $cv_details['experience_end_date']);
                                $experience_descriptions = explode(',', $cv_details['experience_description']);

                                for ($i = 0; $i < count($job_titles); $i++) {
                                    echo '<li><strong>' . htmlspecialchars($job_titles[$i]) . '</strong> at ' . htmlspecialchars($company_names[$i]) . '</li>';
                                    echo '<p><strong>Start Date:</strong> ' . htmlspecialchars($experience_start_dates[$i]) . '</p>';
                                    echo '<p><strong>End Date:</strong> ' . htmlspecialchars($experience_end_dates[$i]) . '</p>';
                                    echo '<p><strong>Description:</strong> ' . nl2br(htmlspecialchars($experience_descriptions[$i])) . '</p>';
                                    echo '<hr>';
                                }
                            ?>
                        </ul>
                    </div>

                    <div class="cv-section">
                        <h6><strong>Skills:</strong></h6>
                        <ul>
                            <?php 
                                $skills = explode(',', $cv_details['skill_name']); 
                                foreach ($skills as $skill) {
                                    echo '<li>' . htmlspecialchars($skill) . '</li>';
                                }
                            ?>
                        </ul>
                    </div>

                    <div class="cv-section">
                        <h6><strong>Tasks:</strong></h6>
                        <ul>
                            <?php 
                                $tasks = explode(',', $cv_details['tasks']);
                                foreach ($tasks as $task) {
                                    echo '<li>' . htmlspecialchars($task) . '</li>';
                                }
                            ?>
                        </ul>
                    </div>

                    <div class="cv-section">
                        <h6><strong>Hobbies:</strong></h6>
                        <ul>
                            <?php 
                                $hobbies = explode(',', $cv_details['hobbies']);
                                foreach ($hobbies as $hobby) {
                                    echo '<li>' . htmlspecialchars($hobby) . '</li>';
                                }
                            ?>
                        </ul>
                    </div>

                    <div class="cv-section">
                        <h6><strong>Languages:</strong></h6>
                        <ul>
                            <?php 
                                $languages = explode(',', $cv_details['languages']);
                                $language_levels = explode(',', $cv_details['language_levels']);
                                for ($i = 0; $i < count($languages); $i++) {
                                    echo '<li>' . htmlspecialchars($languages[$i]) . ' (' . htmlspecialchars($language_levels[$i]) . ')</li>';
                                }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="cv-footer d-flex justify-content-between">
    <button type="button" class="btn btn-primary" onclick="window.location.href='employer.php';">Go Back</button>
</div>
    </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
