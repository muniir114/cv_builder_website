// Function to validate login form
function validateLoginForm() {
    const username = document.querySelector('input[name="username"]').value;
    const password = document.querySelector('input[name="password"]').value;
    if (username === '' || password === '') {
        alert('Please fill in all fields.');
        return false;
    }
    return true;
}

// Function to toggle skill rating input visibility
function toggleSkillRating() {
    const skillsInput = document.querySelector('input[name="skills"]').value;
    const skillRatingContainer = document.getElementById('skill-rating-container');
    
    if (skillsInput.trim() !== '') {
        skillRatingContainer.style.display = 'block';
    } else {
        skillRatingContainer.style.display = 'none';
    }
}


// Function to validate registration form
function validateRegistrationForm() {
    const name = document.querySelector('input[name="name"]').value;
    const email = document.querySelector('input[name="email"]').value;
    const password = document.querySelector('input[name="password"]').value;
    if (name === '' || email === '' || password === '') {
        alert('Please fill in all fields.');
        return false;
    }
    // Simple email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return false;
    }
    return true;
}

// Add event listeners
document.querySelector('form[action="php/login.php"]').addEventListener('submit', function(e) {
    if (!validateLoginForm()) {
        e.preventDefault(); // Prevent form submission
    }
});

document.querySelector('form[action="php/register.php"]').addEventListener('submit', function(e) {
    if (!validateRegistrationForm()) {
        e.preventDefault(); // Prevent form submission
    }
});
// Function to provide input feedback
function provideInputFeedback(inputElement) {
    if (inputElement.value.trim() === '') {
        inputElement.classList.add('invalid');
        inputElement.classList.remove('valid');
    } else {
        inputElement.classList.add('valid');
        inputElement.classList.remove('invalid');
    }
}

// Add event listeners for feedback
const inputs = document.querySelectorAll('input, textarea');
inputs.forEach(input => {
    input.addEventListener('input', function() {
        provideInputFeedback(this);
    });
});

