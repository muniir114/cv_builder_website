<?php
session_start();  // Start the session to check login status
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Builder</title>
    
    <!-- Bootstrap CSS (using the latest version) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/general.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Navigation</h3>
            <a href="index.php">Home</a>
            <a href="php/create_cv.php">Create CV</a>
            <a href="php/contact.php">Contact</a>
            <a href="php/skills_progression.php">Skills Progression</a>
            <a href="php/aboutus.php">About Us</a>         
            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- Show Logout link if the user is logged in -->
                <a href="php/logout.php">Logout</a>
            <?php else: ?>
                <!-- Show Login link if the user is NOT logged in -->
                <a href="php/login.php">Login</a>
            <?php endif; ?>
            

        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <h2>Welcome to CV Builder</h2>
            <p>This application helps you build professional CVs and resumes with ease.</p>
            <button id="moreInfoBtn" class="btn btn-info">More Info</button>
            <div id="moreInfo" class="mt-3" style="display:none;">
                <h3 class="text-center"><strong>About CV Builder</strong></h3>
                <br>
                <p>
                    <strong>CV Builder</strong> is an intuitive web-based platform designed to assist individuals in creating professional and personalized CVs or resumes with ease. 
                    Whether you are a job seeker or a professional looking to update your resume, this platform offers a simple yet powerful interface to get the job done.
                </p>
                <br>
                <h4><strong>Core Features</strong></h4>
                <ul>
                    <li>
                        <strong>Create and Download Your CV:</strong> 
                        Our platform enables you to create a CV step-by-step. You can input your personal details, education background, work experience, skills, and more. 
                        Once completed, you can easily download your CV in PDF format, ready to be sent to potential employers.
                    </li>
                    <li>
                        <strong>Skills Progression Tracking:</strong> 
                        The platform provides a dedicated <strong>Skills Progression</strong> feature where you can monitor the growth of your skills over time. 
                        You can log your improvements and see how your expertise evolves, making it easier to assess your career development.
                    </li>
                    <li>
                        <strong>Customizable CV Sections:</strong> 
                        Choose from a variety of templates and customize sections of your CV, such as work history, education, certifications, and languages.
                        This flexibility ensures that your resume stands out with a unique and professional format.
                    </li>
                </ul>
<br>
                <h4><strong>For Employers</strong></h4>
                <p>
                    Employers can also benefit from this platform by logging into a dedicated <strong>Employer Portal</strong> using their <strong>employer_user</strong> credentials. 
                    Through this portal, employers can view CVs that job applicants have created, enabling them to find qualified candidates based on their skills and experience.
                </p>
                <p>
                    <strong>How Employers Can Register:</strong> Employers who do not yet have an account can create one easily. When you visit the <strong>Login</strong> page, 
                    there is an option to <strong>Register</strong>. During registration, you can select your user role as <strong>Employer</strong>. 
                    By selecting this role, your account will be categorized as an employer, granting you access to the employer portal where you can search for and view applicants’ CVs.
                </p>
<br>
                <h4><strong>About the Creators</strong></h4>
                <p>
                    This website was created by <strong>Mohamed Osman Abdi</strong> and a team of dedicated developers. The goal was to build a user-friendly, efficient, and comprehensive tool 
                    that simplifies the process of building CVs and tracking skill development. Our mission is to help both job seekers and employers by providing an all-in-one solution for resume building and candidate evaluation.
                </p>

                <p>
                    Feel free to explore the different features of the platform, including the <strong>About Us</strong> section to learn more about the team and our vision.
                </p>
            </div>

            <div class="slider-container">
                <div class="slider">
                    <img src="https://images.deepai.org/art-image/999e09d4e39d46b0bfe92b5a1cc3f54a/computer-science-1abf81.jpg" alt="Slide 1" class="slide">
                    <img src="https://images.deepai.org/art-image/8627130ed523497dbdc24db77b7f8ac8/apple-computer-and-computer-science.jpg" alt="Slide 2" class="slide">
                    <img src="https://images.deepai.org/art-image/d17b6a9dce8b47b386571a02fcc98cdb/computer-science-computer-cd1244.jpg" alt="Slide 3" class="slide">
                    <img src="https://images.deepai.org/art-image/0bf86c87236e4fc9a29863fa072aabbb/website-customization-we-customize-websites-t_D0kz3KH.jpg" alt="Slide 4" class="slide">
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <p>&copy; 2024 CV Builder. All rights reserved. Mohamed Osman Abdi</p>
        <div class="footer-icons">
            <a href="https://github.com/turkuai/web-cv-team-4">Github</a>
            <a href="#">Twitter</a>
            <a href="#">Link</a>
            <a href="#">Discord</a>
        </div>
    </footer>

    <!-- Bootstrap JS (Popper.js and Bootstrap JS) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>

    <!-- Custom JS for interaction -->
    <script>
        let index = 0;
        const slides = document.querySelectorAll(".slide");
        const totalSlides = slides.length;

        function moveToNextSlide() {
            index = (index + 1) % totalSlides; // Loop back to the first slide when we reach the last
            const slider = document.querySelector(".slider");
            slider.style.transform = `translateX(-${index * 100}%)`;
        }

        document.getElementById("moreInfoBtn").addEventListener("click", function() {
        var moreInfoDiv = document.getElementById("moreInfo");
        var sliderContainer = document.querySelector(".slider-container");

        // Toggle display of the moreInfo section
        if (moreInfoDiv.style.display === "none") {
            moreInfoDiv.style.display = "block";   // Show the "More Info" text
            sliderContainer.style.display = "none"; // Hide the slider images
        } else {
            moreInfoDiv.style.display = "none";    // Hide the "More Info" text
            sliderContainer.style.display = "block"; // Show the slider images
        }
    });
        setInterval(moveToNextSlide, 3000); // Change slide every 3 seconds
    </script>
</body>
</html>
