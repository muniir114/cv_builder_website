<?php
$targetDir = "uploads/";
$imageFile = ""; // Variable to store uploaded image path

if (isset($_FILES["image"])) {
    $fileName = basename($_FILES["image"]["name"]);
    $targetFile = $targetDir . $fileName;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if the file is an actual image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if the file already exists
    if (file_exists($targetFile)) {
        unlink($targetFile); // Remove existing file
    }

    // Check file size (e.g., max 500KB)
    if ($_FILES["image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow only certain file formats
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif', 'jfif'])) {
        echo "Sorry, only JPG, JPEG, PNG, GIF & JFIF files are allowed.";
        $uploadOk = 0;
    }

    // Upload file if all checks pass
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $imageFile = $targetFile; // Set the uploaded image path
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Builder</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/general.css">

    <style>
        .image-placeholder {
            width: 150px;
            height: 150px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            background-color: #f5f5f5;
            border-radius: 50%; /* Makes it a circle */
            overflow: hidden; /* Ensures image stays within circle */
        }

        .image-placeholder img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
            border-radius: 50%; /* Ensures the image is also a circle */
        }

        .image-placeholder.show-image img {
            display: block;
        }

        .file-input {
            display: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <h3>Navigation</h3>
            <a href="#">Home</a>
            <a href="php/create_cv.php">Create CV</a>
            <a href="php/contact.php">Contact</a>
            <a href="php/skills_progression.php">Skills Progression</a>
            <a href="php/aboutus.php">About Us</a>
            <a href="php/logout.php">Logout</a>
        </div>

        <!-- Main Content Area -->
        <div class="main-content">
            <form action="" method="post" enctype="multipart/form-data" id="uploadForm">
                <div class="row">
                    <!-- Image placeholder that acts as the input -->
                    <div class="image-placeholder" onclick="document.getElementById('fileInput').click();">
                        <img id="uploadedImage" src="" alt="Uploaded Image">
                        <span id="placeholderText">Click to upload an image</span>
                    </div>

                    <!-- Hidden file input -->
                    <input type="file" name="image" id="fileInput" class="file-input" onchange="loadFile(event)" required>
                </div>
            </form>
        </div>
    </div>

    <!-- Footer Section -->
    <footer class="footer">
        <p>&copy; 2024 CV Builder. All rights reserved. Mohamed Osman Abdi</p>
        <div class="footer-icons">
            <a href="https://github.com/turkuai/web-cv-team-4">Github</a>
            <a href="#">Twitter</a>
            <a href="#">Link</a>
            <a href="#">Discord</a>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>

    <!-- JavaScript to handle image preview and form submit -->
    <script>
        // Function to display the selected image as a preview
        function loadFile(event) {
            const fileInput = event.target;
            const placeholder = document.querySelector('.image-placeholder');
            const img = document.getElementById('uploadedImage');
            const placeholderText = document.getElementById('placeholderText');

            if (fileInput.files && fileInput.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    img.src = e.target.result;
                    placeholder.classList.add('show-image');
                    placeholderText.style.display = 'none'; // Hide placeholder text
                };
                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    </script>
</body>
</html>